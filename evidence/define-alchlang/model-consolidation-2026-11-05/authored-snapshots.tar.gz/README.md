# Define AlchLang models

- **v4**: current successor model, organized by business module and use case;
  state machines, ordered policies, queries, durable candidate preparation and
  cross-service review notification. See [v4/README.md](v4/README.md) for source
  selections, profiles, qualification and integration boundaries.
- **v3**: preserved operation-based model organized by meta-type.
- **v2**: runnable authored core currently selected by `define/define-alch`, using
  the existing canonical Work command journal and exact-byte Pack adapter.
- **v1**: preserved small decision models.

A newer model directory does not implicitly rebind the CLI, native Lab store,
owner identity, grants or source profile.
