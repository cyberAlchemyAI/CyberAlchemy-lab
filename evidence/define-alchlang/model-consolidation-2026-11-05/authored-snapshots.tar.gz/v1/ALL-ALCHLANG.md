# Complete authored Define AlchLang source

These are the five authored inputs; generated source snapshots live only under ignored `.local/`.

## context.alch

[Open source](alch/context.alch).

```alchlang
module DefineContext version 1

# Verified source-provider observations enter here. This module does not verify
# identities, signatures, history or artifact bytes itself.
value-object Ref:
  carrier String
  utf8-bytes 1..256
  unicode-scalars 1..256

value-object Selection:
  workspaceProject Ref
  selectedProject Ref
  workProject Ref
  work Ref
  sourceSnapshot Ref
  sourceAvailable Bool
  sourceCurrent Bool
  headCurrent Bool
  viewCurrent Bool
  allowHistoricalSnapshot Bool

enum ContextMode:
  value Current
  value HistoricalSnapshot

enum AuthorityEffect:
  value None

value-object Context:
  project Ref
  work Ref
  sourceSnapshot Ref
  mode ContextMode
  permitsCurrentUse Bool
  authorityEffect AuthorityEffect

rule SameProject:
  input selection Selection
  expression selection.workspaceProject == selection.selectedProject and selection.workProject == selection.selectedProject

rule Current:
  input selection Selection
  expression selection.sourceCurrent and selection.headCurrent and selection.viewCurrent

mapping CurrentContext:
  input selection Selection
  target Context
  total true
  field project <- selection.selectedProject
  field work <- selection.work
  field sourceSnapshot <- selection.sourceSnapshot
  field mode <- Current
  field permitsCurrentUse <- true
  field authorityEffect <- None

mapping HistoricalContext:
  input selection Selection
  target Context
  total true
  field project <- selection.selectedProject
  field work <- selection.work
  field sourceSnapshot <- selection.sourceSnapshot
  field mode <- HistoricalSnapshot
  field permitsCurrentUse <- false
  field authorityEffect <- None

operation SelectContext:
  input selection Selection
  output Context
  on not SameProject(selection) reject project-mismatch
  on not selection.sourceAvailable reject source-unavailable
  when Current(selection):
    return CurrentContext(selection)
  on not selection.allowHistoricalSnapshot reject refresh-context
  return HistoricalContext(selection)
```

## question-cycle.alch

[Open source](alch/question-cycle.alch).

```alchlang
module DefineQuestions version 1

# The adapter retains actual question/answer bytes and commits with CAS.
# A returned proposal neither writes a session nor authenticates the actor.
enum Phase:
  value Ready
  value QuestionOpen

enum Command:
  value Open
  value Answer
  value Defer
  value Refuse

value-object Turn:
  expectedRevision UInt64
  observedRevision UInt64
  phase Phase
  command Command
  contextSufficient Bool
  payloadComplete Bool
  exactQuestionMatches Bool
  unresolvedQuestions UInt64

value-object Progress:
  revision UInt64
  proposal outcome<Phase,Bool,0>
  unresolvedQuestions UInt64
  preservesGap Bool
  authorityGranted Bool

rule CanOpen:
  input state Phase
  input event Command
  expression state == Ready and event == Open

rule CanClose:
  input state Phase
  input event Command
  expression state == QuestionOpen and event != Open

state-machine QuestionCycle:
  state Phase
  input Command
  initial Ready
  transition Ready Open when CanOpen(state,event) -> QuestionOpen
  transition QuestionOpen Answer when CanClose(state,event) -> Ready
  transition QuestionOpen Defer when CanClose(state,event) -> Ready
  transition QuestionOpen Refuse when CanClose(state,event) -> Ready
  otherwise stay

calculation NextRevision:
  pure
  input turn Turn
  result UInt64
  expression turn.observedRevision + 1

calculation RemainingGaps:
  pure
  input turn Turn
  result UInt64
  expression turn.unresolvedQuestions + 1

calculation Proposal:
  pure
  input turn Turn
  result outcome<Phase,Bool,0>
  expression QuestionCycle.propose(turn.phase,turn.command)

mapping Answered:
  input turn Turn
  target Progress
  total true
  field revision <- NextRevision(turn)
  field proposal <- Proposal(turn)
  field unresolvedQuestions <- turn.unresolvedQuestions
  field preservesGap <- false
  field authorityGranted <- false

mapping Deferred:
  input turn Turn
  target Progress
  total true
  field revision <- NextRevision(turn)
  field proposal <- Proposal(turn)
  field unresolvedQuestions <- RemainingGaps(turn)
  field preservesGap <- true
  field authorityGranted <- false

operation Advance:
  input turn Turn
  output Progress
  on turn.expectedRevision != turn.observedRevision reject revision-conflict
  on not turn.contextSufficient reject context-insufficient
  on not turn.payloadComplete reject payload-incomplete
  when turn.command == Open:
    on turn.phase != Ready reject question-already-open
    return Answered(turn)
  on turn.phase != QuestionOpen reject no-current-question
  on not turn.exactQuestionMatches reject question-mismatch
  when turn.command == Answer:
    return Answered(turn)
  return Deferred(turn)
```

## meaning.alch

[Open source](alch/meaning.alch).

```alchlang
module DefineMeaning version 1

# A handling decision preserves scope and posture. Registry selection and
# admission require their own exact owner-authorized runtime transaction.
enum Handling:
  value Reuse
  value Specialize
  value Propose
  value Defer

enum Scope:
  value Work
  value Project
  value Imported

enum SpecializationKind:
  value Meaning
  value Application

enum Placement:
  value ExistingRevision
  value WorkDefinitions
  value ProjectAuthorityDefinitions
  value UpstreamContribution
  value OpenGap
  value PackApplication

value-object MeaningRequest:
  handling Handling
  scope Scope
  specialization SpecializationKind
  sourceExact Bool
  sourceAdmitted Bool
  explicitCandidateEvaluation Bool
  meaningComplete Bool

value-object MeaningPlan:
  placement Placement
  createsDefinitionCandidate Bool
  preserveSourceRevision Bool
  changesSharedSelection Bool
  needsOwnerDecision Bool

mapping Reused:
  input request MeaningRequest
  target MeaningPlan
  total true
  field placement <- ExistingRevision
  field createsDefinitionCandidate <- false
  field preserveSourceRevision <- true
  field changesSharedSelection <- false
  field needsOwnerDecision <- false

mapping Gap:
  input request MeaningRequest
  target MeaningPlan
  total true
  field placement <- OpenGap
  field createsDefinitionCandidate <- false
  field preserveSourceRevision <- true
  field changesSharedSelection <- false
  field needsOwnerDecision <- false

mapping TaskCandidate:
  input request MeaningRequest
  target MeaningPlan
  total true
  field placement <- WorkDefinitions
  field createsDefinitionCandidate <- true
  field preserveSourceRevision <- true
  field changesSharedSelection <- false
  field needsOwnerDecision <- false

mapping ProjectCandidate:
  input request MeaningRequest
  target MeaningPlan
  total true
  field placement <- ProjectAuthorityDefinitions
  field createsDefinitionCandidate <- true
  field preserveSourceRevision <- true
  field changesSharedSelection <- false
  field needsOwnerDecision <- true

mapping Contribution:
  input request MeaningRequest
  target MeaningPlan
  total true
  field placement <- UpstreamContribution
  field createsDefinitionCandidate <- true
  field preserveSourceRevision <- true
  field changesSharedSelection <- false
  field needsOwnerDecision <- true

mapping ApplicationPlan:
  input request MeaningRequest
  target MeaningPlan
  total true
  field placement <- PackApplication
  field createsDefinitionCandidate <- false
  field preserveSourceRevision <- true
  field changesSharedSelection <- false
  field needsOwnerDecision <- false

operation PlanMeaning:
  input request MeaningRequest
  output MeaningPlan
  when request.handling == Defer:
    return Gap(request)
  when request.handling == Reuse:
    on not request.sourceExact reject exact-source-required
    on not request.sourceAdmitted and not request.explicitCandidateEvaluation reject candidate-evaluation-required
    return Reused(request)
  when request.handling == Specialize:
    on not request.sourceExact reject exact-source-required
    when request.specialization == Application:
      return ApplicationPlan(request)
  on not request.meaningComplete reject meaning-incomplete
  when request.scope == Work:
    return TaskCandidate(request)
  when request.scope == Project:
    return ProjectCandidate(request)
  return Contribution(request)
```

## pack.alch

[Open source](alch/pack.alch).

```alchlang
module DefinePack version 1

# This is a readiness projection over independently checked Pack v3 evidence,
# not a replacement schema, serializer, byte custodian or semantic evaluator.
enum Retention:
  value Permitted
  value Unresolved
  value Forbidden

enum Posture:
  value Candidate

value-object Preparation:
  structureValid Bool
  exactSourcesBound Bool
  packageClosureVerified Bool
  retention Retention
  openGaps UInt64
  materializationSelected Bool
  completeDefinition Bool
  fieldLineageComplete Bool
  ownerRouteKnown Bool

value-object Readiness:
  posture Posture
  hasGaps Bool
  retainable Bool
  canMaterialize Bool
  canPrepareOwnerReview Bool
  governingApplication Bool

rule HasGaps:
  input preparation Preparation
  expression preparation.openGaps > 0 or preparation.retention == Unresolved

rule CanMaterialize:
  input preparation Preparation
  expression preparation.materializationSelected and preparation.completeDefinition and preparation.fieldLineageComplete

rule CanReview:
  input preparation Preparation
  expression CanMaterialize(preparation) and preparation.ownerRouteKnown and preparation.retention == Permitted and preparation.openGaps == 0

mapping CandidateReadiness:
  input preparation Preparation
  target Readiness
  total true
  field posture <- Candidate
  field hasGaps <- HasGaps(preparation)
  field retainable <- preparation.retention == Permitted
  field canMaterialize <- CanMaterialize(preparation)
  field canPrepareOwnerReview <- CanReview(preparation)
  field governingApplication <- false

operation AssessPreparation:
  input preparation Preparation
  output Readiness
  on not preparation.structureValid reject invalid-request-or-pack
  on not preparation.exactSourcesBound reject source-binding-mismatch
  on not preparation.packageClosureVerified reject package-closure-mismatch
  on preparation.retention == Forbidden reject retention-forbidden
  return CandidateReadiness(preparation)
```

## lab-handoff.alch

[Open source](alch/lab-handoff.alch).

```alchlang
module DefineLabHandoff version 1

# Observations come from an independently trusted host adapter. A Bool supplied
# by a caller is never a credential. These outputs are intents, not effects.
enum Action:
  value Review
  value Apply
  value Inspect
  value Recover

enum DispatchObservation:
  value NotDispatched
  value DefinitiveNoEffect
  value Unknown
  value Committed

enum NextAction:
  value ReviewProposal
  value ApplyExactProposal
  value InspectOperation
  value RecoverExpectedHead
  value ReturnExistingReceipt

value-object Handoff:
  requested Action
  observation DispatchObservation
  inspectionAuthorized Bool
  operationAuthorized Bool
  sourceCurrent Bool
  expectedHeadMatches Bool
  exactProposalSigned Bool
  operationIdentityMatches Bool
  receiptVerified Bool

value-object Intent:
  next NextAction
  dispatchesWrite Bool
  grantsAuthority Bool

mapping ReviewIntent:
  input handoff Handoff
  target Intent
  total true
  field next <- ReviewProposal
  field dispatchesWrite <- false
  field grantsAuthority <- false

mapping ApplyIntent:
  input handoff Handoff
  target Intent
  total true
  field next <- ApplyExactProposal
  field dispatchesWrite <- false
  field grantsAuthority <- false

mapping InspectIntent:
  input handoff Handoff
  target Intent
  total true
  field next <- InspectOperation
  field dispatchesWrite <- false
  field grantsAuthority <- false

mapping RecoveryIntent:
  input handoff Handoff
  target Intent
  total true
  field next <- RecoverExpectedHead
  field dispatchesWrite <- false
  field grantsAuthority <- false

mapping ExistingReceipt:
  input handoff Handoff
  target Intent
  total true
  field next <- ReturnExistingReceipt
  field dispatchesWrite <- false
  field grantsAuthority <- false

operation PlanHandoff:
  input handoff Handoff
  output Intent
  on not handoff.operationIdentityMatches reject operation-identity-conflict
  when handoff.observation == Unknown:
    on not handoff.inspectionAuthorized reject inspection-authorization-required
    return InspectIntent(handoff)
  when handoff.observation == Committed:
    on not handoff.inspectionAuthorized reject inspection-authorization-required
    when handoff.receiptVerified:
      return ExistingReceipt(handoff)
    return InspectIntent(handoff)
  when handoff.requested == Inspect:
    on not handoff.inspectionAuthorized reject inspection-authorization-required
    return InspectIntent(handoff)
  on not handoff.operationAuthorized reject operation-authorization-required
  on not handoff.expectedHeadMatches reject head-conflict
  when handoff.requested == Recover:
    return RecoveryIntent(handoff)
  on not handoff.sourceCurrent reject source-stale
  when handoff.requested == Review:
    return ReviewIntent(handoff)
  on not handoff.exactProposalSigned reject exact-proposal-approval-required
  return ApplyIntent(handoff)
```

