#!/usr/bin/env node
import {readFileSync, writeFileSync, mkdirSync, mkdtempSync, realpathSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import path from 'node:path';
import {upstreamRoot, implementationRoot as craftRoot} from '../../../../craft/implementation/source-bindings.mjs';

const root = import.meta.dirname;
const selectedNode = path.join(upstreamRoot, '.runtime/craft-release-2026-10-29/node-v26.12.1-linux-x64/bin/node');
if (realpathSync(process.execPath) !== realpathSync(selectedNode)) {
  const child = spawnSync(selectedNode, [import.meta.filename, ...process.argv.slice(2)], {stdio:'inherit'});
  if (child.error) throw child.error;
  process.exit(child.status ?? 1);
}
const mode = process.argv[2] ?? 'verify';
if (!['build','verify'].includes(mode) || process.argv.length > 3) {
  throw Error('Usage: node implementation/define-cli/alchlang/v1/run.mjs [build|verify]');
}
const manifest = name => JSON.parse(readFileSync(path.join(craftRoot, name, 'package.json'), 'utf8'));
const alchlang = manifest('alchlang'), craft = manifest('cli');
if (alchlang.name !== '@cyberalchemy/alchlang' || alchlang.version !== '0.7.0-candidate.0' ||
    craft.name !== '@domainspec-v2/cli' || craft.version !== '1.3.0' || process.versions.node !== '26.12.1') {
  throw Error('Selected imported toolchain identity mismatch');
}
const environment = {...process.env, PATH:path.dirname(selectedNode)+path.delimiter+process.env.PATH,
  ALCHLANG_DOMAINSPEC_PACKAGE_ROOT:path.join(craftRoot,'cli')};
const base = path.join(root,'.local');
mkdirSync(base,{recursive:true});
const output = mkdtempSync(path.join(base,'run-'));
const entries = [
  ['context','DefineContext.SelectContext'],
  ['question-cycle','DefineQuestions.Advance'],
  ['meaning','DefineMeaning.PlanMeaning'],
  ['pack','DefinePack.AssessPreparation'],
  ['lab-handoff','DefineLabHandoff.PlanHandoff'],
];
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const inputs = ['run.mjs','profile.json','alch/contracts/bounds.json',
  'tests/model.test.mjs','tests/standalone-observation.py',...entries.map(([name])=>'alch/'+name+'.alch')];
const digestInputs = () => Object.fromEntries(inputs.map(name=>[name,sha(readFileSync(path.join(root,name)))]));
const captured = digestInputs();
function run(label,args,extra={}) {
  const child = spawnSync(selectedNode,args,{cwd:root,env:{...environment,...extra},encoding:'utf8',maxBuffer:16*1024*1024});
  writeFileSync(path.join(output,label+'.stdout'),child.stdout ?? '');
  writeFileSync(path.join(output,label+'.stderr'),child.stderr ?? '');
  if (child.error || child.status !== 0) throw Error(label+' failed; retained in '+output+'\n'+(child.stderr || child.stdout || child.error));
  return child.stdout;
}
console.log('Generating Define with AlchLang '+alchlang.version+', Craft '+craft.version+'; '+output);
for (const [name,operation] of entries) {
  run(name,[path.join(craftRoot,'alchlang/dist/generic-composition-cli.js'),'generate',
    '--source',path.join(root,'alch',name+'.alch'),'--profile',path.join(root,'profile.json'),
    '--operation',operation,'--out',path.join(output,name),
    '--accept-local-review','define-model-local-validation']);
  console.log('Generated '+operation);
}
if (JSON.stringify(captured) !== JSON.stringify(digestInputs())) throw Error('Source changed during generation');
let tests = null;
if (mode === 'verify') {
  const checks = run('checks',['--test',path.join(root,'tests/model.test.mjs')],{DEFINE_MODEL_OUTPUT:output});
  process.stdout.write(checks);
  tests = Object.fromEntries([...checks.matchAll(/^(?:ℹ|#) (tests|pass|fail) (\d+)/gm)].map(match=>[match[1],Number(match[2])]));
  if (!tests.tests || tests.pass !== tests.tests || tests.fail !== 0) throw Error('Missing or incomplete verification summary');
}
if (JSON.stringify(captured) !== JSON.stringify(digestInputs())) throw Error('Source changed during verification');
const report = {schema_version:'cal.define-alchlang-model-verification/v1',
  status:mode === 'verify'?'PASS':'BUILT',completed_at:new Date().toISOString(),
  standing:'executable-candidate-domain-model',authority_effect:'none',
  toolchain:{alchlang:alchlang.version,craft:craft.version,node:process.versions.node,
    alchlang_root:path.relative(root,path.join(craftRoot,'alchlang')),craft_root:path.relative(root,path.join(craftRoot,'cli'))},
  source_sha256:captured,operations:entries.map(([,operation])=>operation),tests,output,
  live_connector_replaced:false,lab_owner_operations_executed:false};
writeFileSync(path.join(output,'result.json'),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report,null,2));
