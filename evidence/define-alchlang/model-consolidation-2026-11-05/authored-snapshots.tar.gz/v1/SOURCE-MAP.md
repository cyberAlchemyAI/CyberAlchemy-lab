# Evidence and implementation boundary

The new model is authored against the current imported compiler and current
Define/Lab sources. These links are evidence, not a claim of automatic runtime
binding. Existing entrypoints and signed source selections were not changed.

| Model source | Existing source used | What is still proposed |
| --- | --- | --- |
| `context.alch` | [connector context](../../lab-integration/v1/define_lab/host.py), [native Session](../../../lab-runtime/v2/lab_runtime/session.py) | Workspace/project selection, Work selection and separately authorized historical context. Current connector fixes context to Lab Project State. |
| `question-cycle.alch` | [durable session core](../../v1/src/durable-session-runtime.mjs), [historical question model](../../../../define/source/cyberAlchemy-v2/implementation/define-cli/experiments/define-runtime-rewrite-v1/question-cycle.alch) | An explicit adapter from question proposals to authenticated durable Work/session writes. Default chat is not automatically durable. |
| `meaning.alch` | [standalone preparation](../../standalone/define_core/prepare.py), [materialization](../../standalone/define_core/materialize.py), [proposed J03](../../../../product/lab/design/journeys/project-lifecycle.md#j03--introduce-or-change-a-definition) | Work/project/import scope routing, upstream contribution and successor registry publication. The connector currently materializes new identities only. |
| `pack.alch` | [Pack v3 schema](../../standalone/define_core/schemas/pack.schema.json), [byte API](../../standalone/define_core/api.py) | Explicit adapter for the compact readiness projection; it is not complete Pack readiness equivalence. Ordinary output handoff still needs connector changes. |
| `lab-handoff.alch` | [connector review/apply/reconstruct](../../lab-integration/v1/define_lab/host.py), [native Store](../../../lab-runtime/v2/lab_runtime/store.py) | Connector operation inspection/recovery and unknown-outcome reconciliation, with separate inspection authority. The model does not repair post-commit exception classification. |

Compiler evidence:

- [Imported implementation selection](../../../../craft/implementation/README.md).
- [AlchLang manifest](../../../../craft/implementation/alchlang/package.json),
  [Craft Core manifest](../../../../craft/implementation/cli/package.json).
- [Generic application contract](../../../../craft/implementation/alchlang/docs/GENERIC-APPLICATIONS.md)
  and [executable source example](../../../../craft/implementation/alchlang/examples/generic-decision/business.alch).
- [Generic compiler entrypoint](../../../../craft/implementation/alchlang/src/generic-composition-cli.ts).

The finite checks exercise actual generated code, denial/error boundaries and
one ordinary standalone Pack's exact reconstruction. They do not establish
universal semantic truth, all-six-journey completion, production provider
qualification, a new governing owner decision or a default CLI migration.
