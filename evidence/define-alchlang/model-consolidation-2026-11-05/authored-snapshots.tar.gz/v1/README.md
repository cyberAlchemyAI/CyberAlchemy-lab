# Define in AlchLang and Craft

Define turns an intent into explicit scope, questions, meanings and a candidate
Definition Pack. Lab handles the independently authorized review, commit and
recovery of governed records. This package makes the decision core executable
from AlchLang source through the recently imported Craft compiler.

Standing: **executable candidate domain model**. Created 2026-11-05.
It is an explicit new implementation lane. The default Define command and local
Lab connector have not switched to it. The five generated Operations execute;
they do not run a conversation model, create a project, serialize a complete
Pack, store Work or make owner decisions.

## Run it

From the Lab root:

```sh
node implementation/define-cli/alchlang/v1/run.mjs verify
node implementation/define-cli/alchlang/v1/run.mjs build
```

The runner selects the imported AlchLang **0.7.0-candidate.0**, local Craft Core
**1.3.0**, and the existing shared Node **26.12.1** installation. These are the
versions selected by `craft/implementation/run.mjs`; the older Craft/RUNTIME.json
and historical Body War assessment select different contracts. No runtime or
dependency installation is copied or modified. No network is required.

Each invocation creates a new ignored `.local/run-*` directory. It contains the
five generated `operation.mjs` modules, source captures, business/system/bridge
graphs, compiler manifests, local review records, logs and `result.json`.
`verify` also executes the actual generated modules and the standalone byte API
comparison. A failed run retains its diagnostics. This is source-checkout
qualification; it is not an independently installed archive qualification.

The generation review label `define-model-local-validation` records local compiler
acceptance. It is not an authenticated semantic owner decision or Lab grant.
`profile.json` selects the pure bounded-values/StateMachine profile. Its limits
match `alch/contracts/bounds.json`; Craft reads bounds beside the source.

## All authored AlchLang files

| Source | Executable Operation | Its responsibility |
| --- | --- | --- |
| [context.alch](alch/context.alch) | `DefineContext.SelectContext` | Keep the selected workspace, Project, Work and exact source together; distinguish current use from explicit historical inspection. |
| [question-cycle.alch](alch/question-cycle.alch) | `DefineQuestions.Advance` | Propose one revision-checked question transition; answers close the question, deferral/refusal preserves a gap. |
| [meaning.alch](alch/meaning.alch) | `DefineMeaning.PlanMeaning` | Reuse a revision, bind task parameters, propose a meaning or retain an open gap; route by scope. |
| [pack.alch](alch/pack.alch) | `DefinePack.AssessPreparation` | Project checked preparation evidence into separate custody, materialization and owner-review readiness. |
| [lab-handoff.alch](alch/lab-handoff.alch) | `DefineLabHandoff.PlanHandoff` | Plan review/apply/inspection/recovery while preserving operation identity and uncertain outcomes. |

[Read all five complete sources together](ALL-ALCHLANG.md).
Compiler-generated `.alch` capture/technical files under `.local` are derived
artifacts, not additional authored Define source. Historical imported Define
AlchLang remains in `define/source/cyberAlchemy-v2/` and the current v1 realization.

The selected pure compiler admits one source module per generation. Consequently
these modules are independently checked, and the driver explicitly connects
their typed observations. There are no invented cross-file imports or implicit
Workflow effects. A future stateful application profile needs its own contracts.

## How they compose

```mermaid
flowchart LR
    U[User intent] --> A[Agent and source adapters]
    A --> C[Project and Work context]
    C --> Q[Questions and remaining gaps]
    Q --> M[Meaning and scope decisions]
    M --> P[Candidate Pack readiness]
    P --> H[Lab handoff intent]
    H --> R[Authorized runtime adapter]
    R --> O[Observed result or uncertainty]
    O --> H
```

The AlchLang files contain the rules, branches, calculations, output mappings and
question StateMachine. Craft checks their types and selected capability limits,
captures the sources and generates executable Node modules and graph views.
JavaScript supplies build/test orchestration. It does not duplicate the business
branching in a second implementation.

Generated Operations accept UTF-8 JSON bytes through `evaluate(bytes)`. A business
rejection is `ok:true` containing `Rejected`; malformed values and computation
failures are `ok:false`. A successful return is still a domain result or intent.
Question StateMachine proposals contain zero effect intents and never persist
their proposed state. Even `ApplyExactProposal` dispatches no write here.

## Example: context-management Work

1. Select `project:context-management` and its `work:retrieval`. A Work belonging
   to the Lab or another Project refuses with `project-mismatch`.
2. Open a question about what counts as useful retained context. Defer it when
   evidence is missing; the next revision retains an unresolved gap.
3. Propose a project-wide meaning. Its destination is
   `authority/definitions/<term>/vN/`, with candidate posture inside the record.
   A Work-only meaning instead belongs in `work/<id>/define/definitions/`.
   Both preserve previous revision references; neither changes shared selection.
4. Prepare candidate Pack evidence. An unresolved question stays visible and
   blocks complete definition owner-review readiness. An ordinary output with
   no definition materialization remains representable.
5. Review and application remain separate runtime actions. If a write might
   have committed, the next intent is `InspectOperation`. Verified committed
   results return their existing receipt rather than another write.

The context-management example uses authored hypothetical project observations.
It does not create that project or establish any journey as observed successful.

## Verification

[Recorded verification](VERIFICATION.json): all five Operations generated and
19/19 checks passed. The existing default Define doctor also passed with 552
selected files, and the existing local connector doctor verified its 56-file
closure. Neither command was rebound to this package.

## Integration contracts and remaining work

See [SOURCE-MAP.md](SOURCE-MAP.md) for source evidence and current/proposed behavior.
The input records are normalized adapter contracts, not new versions of Pack v3,
Definition/v2, native Lab proposals or permission credentials. In particular:

- Source and identity adapters must verify history, exact bytes, signatures,
  source/head freshness and the Work-to-Project binding before producing facts.
  Supplying `operationAuthorized: true` in JSON authenticates nobody.
- A session adapter must retain actual question/answer bytes and perform an
  atomic compare-and-swap. The model proposes the next revision; it cannot
  prevent a concurrent writer by itself. `unresolvedQuestions` counts previously
  deferred/refused questions, excluding the currently open question.
- The meaning adapter must preserve admission observations, exact versions,
  full definition bodies, applications, lineage and owner routes. `Reuse` with
  explicit candidate evaluation grants no admitted standing. Parameter
  specialization makes a Pack application rather than a shared definition.
- The Pack adapter must use the actual standalone API for byte validation,
  construction, custody and reconstruction. The compact readiness projection
  does not implement every named-use obligation or replace its report. It never
  runs a reported domain assessment or grants governing application.
- The Lab adapter must independently enforce current operation-specific access,
  signed exact proposals, expected head, operation identity, inspection access
  and verified receipts. An unknown result cannot be relabeled definitive-no-effect
  from a timeout. Recovery uses the exact expected head and native recovery
  rules; historical inspection does not require effect permission.

The existing connector still needs the independently owned project bootstrap,
general Work adapter, bounded authenticated delegation, revision/registry
publication and team clone/artifact/cache work identified in the journey audit.
Git-authored authority/Work records, external immutable shared artifact bytes and
rebuildable local SQLite remain the intended persistence model. This package
introduces no project database or migrations.
