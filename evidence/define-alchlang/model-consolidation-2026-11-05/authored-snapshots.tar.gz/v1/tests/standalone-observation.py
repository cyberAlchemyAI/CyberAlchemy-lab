"""Read-only byte API comparison. No native Lab grant, store or owner action."""
import base64
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[3] / 'standalone'))
from define_core import call
from define_core.example import example_members

members = example_members()
request = members.pop('request.json').decode('utf-8')
inputs = {name: base64.b64encode(raw).decode('ascii') for name, raw in members.items()}

def invoke(operation, params):
    result = call({'api_version': 'define.api/v1', 'id': 'alchlang-observation-' + operation,
                   'operation': operation, 'params': params})
    assert result['outcome'] in ('prepared', 'prepared-with-gaps'), result
    return result['data']

capture = invoke('capture', {'request_utf8': request, 'inputs': inputs, 'permit_retention': True})
prepared = invoke('prepare', {'request_utf8': request, 'capture_utf8': capture['capture_utf8'],
                              'inputs': capture['inputs']})
restored = invoke('reconstruct', {'package_members': prepared['package_members']})
pack, report = prepared['pack'], prepared['report']
print(json.dumps({'status': pack['status'], 'authority_effect': pack['authority_effect'],
    'reconstructed_exactly': restored['package_members'] == prepared['package_members'],
    'assessment_execution_count': report['assessment_execution_count'],
    'governing_application': pack['readiness']['governing-application']['outcome'],
    'model_input': {'structureValid': True, 'exactSourcesBound': True,
        'packageClosureVerified': True, 'retention': 'Permitted', 'openGaps': str(len(pack['gaps'])),
        'materializationSelected': bool(pack['materialization_selection']),
        'completeDefinition': False, 'fieldLineageComplete': False, 'ownerRouteKnown': False}}))
