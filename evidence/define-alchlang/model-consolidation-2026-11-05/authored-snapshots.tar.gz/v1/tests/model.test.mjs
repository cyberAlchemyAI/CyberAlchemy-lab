import test from 'node:test';
import assert from 'node:assert/strict';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import {spawnSync} from 'node:child_process';

const root = path.resolve(import.meta.dirname,'..');
const output = process.env.DEFINE_MODEL_OUTPUT;
assert(output,'Run through ../run.mjs verify');
const encode = value => new TextEncoder().encode(JSON.stringify(value));
const modules = new Map();
async function evaluate(name,argument,value) {
  if (!modules.has(name)) modules.set(name,await import(pathToFileURL(path.join(output,name,'operation.mjs')).href));
  return modules.get(name).evaluate(encode({[argument]:value}));
}
async function outcome(name,argument,value) {
  const result = await evaluate(name,argument,value);
  assert.equal(result.ok,true,JSON.stringify(result.error));
  return JSON.parse(new TextDecoder().decode(result.wire));
}
async function returned(name,argument,value) {
  const result = await outcome(name,argument,value);
  assert.equal(result.tag,'Returned',JSON.stringify(result));
  return result.fields.value;
}
async function rejected(name,argument,value,code) {
  assert.deepEqual(await outcome(name,argument,value),{tag:'Rejected',fields:{code}});
}
const context = () => ({workspaceProject:'project:context-management',selectedProject:'project:context-management',
  workProject:'project:context-management',work:'work:retrieval',sourceSnapshot:'sha256:source-cut',
  sourceAvailable:true,sourceCurrent:true,headCurrent:true,viewCurrent:true,allowHistoricalSnapshot:false});
const turn = () => ({expectedRevision:'3',observedRevision:'3',phase:'Ready',command:'Open',
  contextSufficient:true,payloadComplete:true,exactQuestionMatches:true,unresolvedQuestions:'2'});
const meaning = () => ({handling:'Propose',scope:'Project',specialization:'Meaning',sourceExact:true,
  sourceAdmitted:true,explicitCandidateEvaluation:false,meaningComplete:true});
const preparation = () => ({structureValid:true,exactSourcesBound:true,packageClosureVerified:true,
  retention:'Permitted',openGaps:'0',materializationSelected:true,completeDefinition:true,
  fieldLineageComplete:true,ownerRouteKnown:true});
const handoff = () => ({requested:'Apply',observation:'NotDispatched',inspectionAuthorized:true,
  operationAuthorized:true,sourceCurrent:true,expectedHeadMatches:true,exactProposalSigned:true,
  operationIdentityMatches:true,receiptVerified:false});

test('context keeps Project, Work and exact source together',async()=>{
  assert.deepEqual(await returned('context','selection',context()),{project:'project:context-management',
    work:'work:retrieval',sourceSnapshot:'sha256:source-cut',mode:'Current',permitsCurrentUse:true,authorityEffect:'None'});
});
test('foreign Work or workspace refuses even if historical inspection was requested',async()=>{
  for (const field of ['workProject','workspaceProject']) {
    await rejected('context','selection',{...context(),[field]:'project:other',allowHistoricalSnapshot:true},'project-mismatch');
  }
});
test('stale source, head or view needs refresh or explicit historical use',async()=>{
  for (const field of ['sourceCurrent','headCurrent','viewCurrent']) {
    const stale={...context(),[field]:false};
    await rejected('context','selection',stale,'refresh-context');
    const historical=await returned('context','selection',{...stale,allowHistoricalSnapshot:true});
    assert.equal(historical.mode,'HistoricalSnapshot'); assert.equal(historical.permitsCurrentUse,false);
  }
  await rejected('context','selection',{...context(),sourceAvailable:false,allowHistoricalSnapshot:true},'source-unavailable');
});
test('one question at a time; answered and deferred turns return to Ready',async()=>{
  const opened=await returned('question-cycle','turn',turn());
  assert.equal(opened.proposal.state,'QuestionOpen'); assert.equal(opened.revision,'4');
  assert.deepEqual(opened.proposal.intents,[]); assert.equal(opened.authorityGranted,false);
  await rejected('question-cycle','turn',{...turn(),phase:'QuestionOpen'},'question-already-open');
  for (const command of ['Answer','Defer','Refuse']) {
    const next=await returned('question-cycle','turn',{...turn(),phase:'QuestionOpen',command});
    assert.equal(next.proposal.state,'Ready'); assert.equal(next.unresolvedQuestions,command==='Answer'?'2':'3');
    assert.equal(next.preservesGap,command!=='Answer');
  }
});
test('question mismatch, stale revision, incomplete content and missing context refuse',async()=>{
  for (const [patch,code] of [[{expectedRevision:'2'},'revision-conflict'],
    [{contextSufficient:false},'context-insufficient'],[{payloadComplete:false},'payload-incomplete'],
    [{command:'Answer'},'no-current-question'],[{command:'Answer',phase:'QuestionOpen',exactQuestionMatches:false},'question-mismatch']]) {
    await rejected('question-cycle','turn',{...turn(),...patch},code);
  }
});
test('revision overflow is a typed evaluator failure, not a rejected or successful turn',async()=>{
  const result=await evaluate('question-cycle','turn',{...turn(),expectedRevision:'18446744073709551615',observedRevision:'18446744073709551615'});
  assert.equal(result.ok,false); assert.equal(result.error.code,'ArithmeticOverflow');
});
test('task, project and imported candidates have different destinations and keep selection intact',async()=>{
  for (const [scope,placement,owner] of [['Work','WorkDefinitions',false],['Project','ProjectAuthorityDefinitions',true],['Imported','UpstreamContribution',true]]) {
    const result=await returned('meaning','request',{...meaning(),scope});
    assert.equal(result.placement,placement); assert.equal(result.createsDefinitionCandidate,true);
    assert.equal(result.changesSharedSelection,false); assert.equal(result.preserveSourceRevision,true);
    assert.equal(result.needsOwnerDecision,owner);
  }
});
test('explicit candidate examination preserves source posture; reuse never admits it',async()=>{
  const request={...meaning(),handling:'Reuse',sourceAdmitted:false};
  await rejected('meaning','request',request,'candidate-evaluation-required');
  const result=await returned('meaning','request',{...request,explicitCandidateEvaluation:true});
  assert.equal(result.placement,'ExistingRevision'); assert.equal(result.changesSharedSelection,false);
  assert.equal(result.createsDefinitionCandidate,false);
});
test('task parameter specialization makes a Pack application, not a new definition',async()=>{
  const result=await returned('meaning','request',{...meaning(),handling:'Specialize',specialization:'Application'});
  assert.equal(result.placement,'PackApplication'); assert.equal(result.createsDefinitionCandidate,false);
  await rejected('meaning','request',{...meaning(),handling:'Specialize',sourceExact:false},'exact-source-required');
  assert.equal((await returned('meaning','request',{...meaning(),handling:'Defer',meaningComplete:false})).placement,'OpenGap');
  await rejected('meaning','request',{...meaning(),meaningComplete:false},'meaning-incomplete');
});
test('complete Pack remains candidate with no governing application',async()=>{
  assert.deepEqual(await returned('pack','preparation',preparation()),{posture:'Candidate',hasGaps:false,
    retainable:true,canMaterialize:true,canPrepareOwnerReview:true,governingApplication:false});
});
test('ordinary Work outputs do not require Definition materialization',async()=>{
  const result=await returned('pack','preparation',{...preparation(),materializationSelected:false,completeDefinition:false,fieldLineageComplete:false});
  assert.equal(result.retainable,true); assert.equal(result.canMaterialize,false); assert.equal(result.canPrepareOwnerReview,false);
});
test('open questions or unresolved retention remain visible; forbidden custody refuses',async()=>{
  for (const patch of [{openGaps:'1'},{retention:'Unresolved'}]) {
    const result=await returned('pack','preparation',{...preparation(),...patch});
    assert.equal(result.hasGaps,true); assert.equal(result.canPrepareOwnerReview,false);
  }
  assert.equal((await returned('pack','preparation',{...preparation(),retention:'Unresolved'})).retainable,false);
  await rejected('pack','preparation',{...preparation(),retention:'Forbidden'},'retention-forbidden');
  for (const [field,code] of [['structureValid','invalid-request-or-pack'],['exactSourcesBound','source-binding-mismatch'],['packageClosureVerified','package-closure-mismatch']]) {
    await rejected('pack','preparation',{...preparation(),[field]:false},code);
  }
});
test('full carrier, field lineage and owner route are separate requirements',async()=>{
  for (const field of ['completeDefinition','fieldLineageComplete']) {
    const result=await returned('pack','preparation',{...preparation(),[field]:false});
    assert.equal(result.canMaterialize,false); assert.equal(result.canPrepareOwnerReview,false);
  }
  const ownerMissing=await returned('pack','preparation',{...preparation(),ownerRouteKnown:false});
  assert.equal(ownerMissing.canMaterialize,true); assert.equal(ownerMissing.canPrepareOwnerReview,false);
});
test('unknown writes always require inspection, including stale-source and expired-effect cases',async()=>{
  for (const requested of ['Review','Apply','Inspect','Recover']) {
    for (const operationAuthorized of [true,false]) {
      const intent=await returned('lab-handoff','handoff',{...handoff(),requested,observation:'Unknown',operationAuthorized,sourceCurrent:false,expectedHeadMatches:false});
      assert.equal(intent.next,'InspectOperation'); assert.equal(intent.dispatchesWrite,false); assert.equal(intent.grantsAuthority,false);
    }
  }
  await rejected('lab-handoff','handoff',{...handoff(),observation:'Unknown',inspectionAuthorized:false},'inspection-authorization-required');
});
test('committed writes return verified receipts and cannot dispatch twice',async()=>{
  for (const receiptVerified of [true,false]) {
    const result=await returned('lab-handoff','handoff',{...handoff(),observation:'Committed',receiptVerified,operationAuthorized:false,sourceCurrent:false});
    assert.equal(result.next,receiptVerified?'ReturnExistingReceipt':'InspectOperation'); assert.equal(result.dispatchesWrite,false);
  }
});
test('review, exact apply and pending recovery require their own checked evidence',async()=>{
  for (const [patch,code] of [[{operationIdentityMatches:false},'operation-identity-conflict'],
    [{operationAuthorized:false},'operation-authorization-required'],[{expectedHeadMatches:false},'head-conflict'],
    [{sourceCurrent:false},'source-stale'],[{exactProposalSigned:false},'exact-proposal-approval-required']]) {
    await rejected('lab-handoff','handoff',{...handoff(),...patch},code);
  }
  assert.equal((await returned('lab-handoff','handoff',handoff())).next,'ApplyExactProposal');
  assert.equal((await returned('lab-handoff','handoff',{...handoff(),requested:'Review',exactProposalSigned:false})).next,'ReviewProposal');
  assert.equal((await returned('lab-handoff','handoff',{...handoff(),requested:'Recover',sourceCurrent:false,exactProposalSigned:false})).next,'RecoverExpectedHead');
});
test('invalid Boolean input is not accepted as verified host evidence',async()=>{
  const result=await evaluate('lab-handoff','handoff',{...handoff(),operationAuthorized:'true'});
  assert.equal(result.ok,false);
});
test('generated model executes a context-management example across all five components',async()=>{
  const selected=await returned('context','selection',context());
  const question=await returned('question-cycle','turn',turn());
  const deferred=await returned('question-cycle','turn',{...turn(),observedRevision:question.revision,
    expectedRevision:question.revision,phase:question.proposal.state,command:'Defer'});
  const planned=await returned('meaning','request',meaning());
  const pack=await returned('pack','preparation',{...preparation(),openGaps:deferred.unresolvedQuestions});
  assert.equal(pack.hasGaps,true); assert.equal(pack.canPrepareOwnerReview,false);
  const recovery=await returned('lab-handoff','handoff',{...handoff(),observation:'Unknown'});
  assert.equal(selected.work,'work:retrieval'); assert.equal(planned.placement,'ProjectAuthorityDefinitions');
  assert.equal(recovery.next,'InspectOperation');
});
test('standalone Pack v3 actual preparation/reconstruction agrees with the bounded candidate projection',async()=>{
  const child=spawnSync('python3',[path.join(root,'tests/standalone-observation.py')],{
    encoding:'utf8',env:{...process.env,PYTHONDONTWRITEBYTECODE:'1'},maxBuffer:1024*1024});
  assert.equal(child.status,0,child.stderr);
  const observation=JSON.parse(child.stdout);
  assert.equal(observation.status,'candidate'); assert.equal(observation.authority_effect,'none');
  assert.equal(observation.reconstructed_exactly,true); assert.equal(observation.assessment_execution_count,0);
  assert.equal(observation.governing_application,'blocked');
  const model=await returned('pack','preparation',observation.model_input);
  assert.equal(model.posture,'Candidate'); assert.equal(model.governingApplication,false);
  assert.equal(model.hasGaps,true); assert.equal(model.canMaterialize,false);
});
