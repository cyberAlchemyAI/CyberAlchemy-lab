# Observed compiler boundaries

Observed against imported AlchLang 0.7.0-candidate.0 / Core 1.3.0 on 2026-11-05.
No compiler source was changed.

| Attempt | Actual result | Consequence in the final model |
| --- | --- | --- |
| Call an Operation in another business module as an ordinary helper | `InvalidContract: cross-module invocation requires an entry or exact native protocol Interface` | Internal business actions share the application module. |
| Split one module header across two source files | `DuplicateSymbol: duplicate source identity` | Independent files use independent modules. |
| Select the transaction profile for an entirely pure application | `MissingMapping: atomic source needs actual stateful Operation` | Explicit disposable projection transaction; no invented authoritative persistence. |
| Compose Operations from a read-only Operation | `UnsupportedCapability: readonly step outside closed guard/read/conditional/action scope` | Same-service Operation calls live in stateful orchestration. |
| Use successful early-return branches inside stateful preflight | `UnsupportedCapability` under its closed preflight/action rules | Linear guarded-handler pipeline, transaction, then one terminal result. |

These are profile/implementation restrictions. They do not establish that the
AlchLang language can never support other composition styles. The successful
model uses actual imported source capture, type checking, generation and runtime
owners; it does not emulate the rejected forms in a custom transpiler.
