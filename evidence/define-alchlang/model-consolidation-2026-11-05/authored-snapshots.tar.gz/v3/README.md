# Define — modular Operation model

This model expresses Define's business actions as **Operations**, Boolean checks
as **Rules**, record construction as **Mappings**, and derived values as
**Calculations**. It compiles thirteen independent AlchLang source files using
the imported AlchLang 0.7.0-candidate.0 and Craft Core 1.3.0.

It is a separately qualified candidate model. The existing `define-alch` CLI
still selects the frozen [v2 implementation](../v2/README.md). Existing Work
journals, native Lab stores, keys, grants and source selections are unchanged.

## Files and responsibilities

```text
v3/
├── model/
│   ├── common.alch          identifiers, text, digests, bindings and shared outcomes
│   ├── context.alch         scope and attributable context assessment
│   ├── questions.alch       questions, responses and their status
│   ├── meanings.alch        meanings, parameters, references and concept handling
│   ├── applications.alch    parameter applications and value provenance
│   ├── assessments.alch     reported results, producers, gaps and limits
│   ├── packs.alch           Pack request, materialization and request lineage
│   └── sessions.alch        session state, commands and command payloads
├── operations.alch          guarded business actions, orchestration and Entry
├── rules.alch               sufficiency, open-question, binding and readiness checks
├── mappings.alch            construct sessions, Pack requests and response records
├── calculations.alch        collection derivations and typed selectors
├── ports.alch               agent, source, Pack, Lab and projection contracts
├── sources.json             explicit source closure and selected Entry
├── profile.json             selected imported compiler/application profile
├── contracts/               computation and transaction bounds
├── build.mjs                invoke the actual imported compiler
├── verify.mjs               isolated native qualification driver
└── qualify-pack.py          exact existing Pack/Definition byte-port witness
```

The files above are the authored sources. Build does not concatenate sources,
rename symbols, inline Operations or modify the imported compiler. Each file
has its own module and explicit `use` imports. `sources.json` supplies the
primary and additional files to the compiler's actual multi-source path.

## Business actions

[operations.alch](operations.alch) contains `StartSession`, `StartSuccessor`,
`SetContext`, `AskQuestion`, `RespondToQuestion`, `RequireConcept`, `RecordMeaning`,
`BindSource`, `BindEvidence`, `RecordApplication`, `RecordAssessment`,
`SelectMaterialization`, `SetValidation`, `ConfirmCandidate`, `CloseSession`,
`ResumeSession` and `ExportPreparation`.

Their guards produce actual Operation rejection outcomes. For example,
`AskQuestion` refuses insufficient context, an already open question and a
repeated question identity. Its successful result comes from the `WithQuestion`
Mapping. That Mapping constructs the next record; it does not decide whether
the business action is allowed.

`ValidateInvocation` checks session, Project, Work, revision and closed-session
conditions. `Execute` composes the business Operations under the selected profile.
The retained `Result`/`Reply` data contracts preserve compatibility with the
existing candidate representation; business guard failures propagate through
Craft's actual `Rejected` outcome rather than being concealed in a Calculation.

## Why Operations share one file

The imported compiler has specific composition boundaries:

1. The pure profile rejects additional source files and Operation-to-Operation
   invocation. The transaction application profile admits multiple sources and
   calls to same-service zero-effect Operations from stateful preflight.
2. Two files declaring the same module reject as duplicate source identities.
   Cross-module Operation invocation requires an Entry or an admitted native
   protocol; it is not an ordinary internal helper call.
3. The selected stateful preflight admits a linear sequence of calls, guards
   and bounded conditionals followed by its transaction and result. General
   early successful returns inside orchestration are outside that contract.

Consequently, business Operations share `Define.Actions`. The surrounding
records, predicates, transformations and derivations are independent modules.
Each business Operation accepts the current candidate and invocation, handles
its own command and otherwise passes the candidate through unchanged. Exactly
one command handler changes the session. `Execute` connects those handlers in
a linear pipeline, then runs request export when selected.

Splitting each business Operation into a separate module while retaining direct
internal calls would require another admitted compiler capability. This model
records that restriction rather than hiding it in generated source assembly.

## SQLite is an explicit disposable projection

The selected application profile requires a real stateful Operation. The model
therefore includes `Projection` and an explicit `CacheProjection` invocation.
It stores a candidate Session with a caller-supplied source digest. Normal
business commands produce their candidate result without inserting a projection.
The framework also retains its local command-result journal for replay.

These SQLite records are disposable qualification/projection data. They do not
replace the canonical Work journal, publish definitions or establish native Lab
authority. A production adapter must bind a projection to verified canonical
Work history and provide actual authentication. The declared `Command.actor`
also needs binding to that authenticated identity; it is currently provenance
text, not authentication evidence. This package does not switch
the v2 Work adapter to SQLite, provision production credentials or implement
remote team coordination.

## Build and qualify

From the Lab root:

```bash
node implementation/define-cli/alchlang/v3/verify.mjs build
node implementation/define-cli/alchlang/v3/verify.mjs verify
```

The driver selects the existing shared Node 26.12.1 installation and local
imported Craft packages. Generated artifacts, dependency links and native test
fixtures stay under ignored `.local/`; shared runtimes are not copied.

`build` generates the application from all thirteen sources. `verify` creates
explicitly isolated Auth and SQLite fixtures, invokes the generated application
through the original Core SDK, exercises business rejection and command replay,
and checks a full User Journey request against the existing Pack v3 and
Definition/v2 byte implementation. It records [VERIFICATION.json](VERIFICATION.json).
Fixture subjects and grants are not actual Lab owners or qualified operators.

The profile bounds inputs and results to 65,536 bytes, as required by the
imported transaction recipe. This is a narrower operational envelope than v2's
pure profile. Oversized calls refuse. No source records are truncated to fit.
Model completion and these finite observations do not establish complete CLI
replacement, all-six-journey completion, semantic admission or deployment.
