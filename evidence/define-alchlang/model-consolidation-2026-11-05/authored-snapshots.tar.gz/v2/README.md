# Define — AlchLang implementation

Define turns an authored intent into attributable questions, meanings,
applications and candidate Definition Packs. Its domain behavior is authored in
[define.alch](define.alch), checked and compiled by the recently imported
AlchLang **0.7.0-candidate.0** and Craft Core **1.3.0**. The explicit CLI is
`./define/define-alch`. This is the successor to the five small v1 decision models.

Standing: **working local candidate implementation**. It has its own versioned
session contract and explicit entrypoint. It does not replace default Define,
rewrite existing v1/v2/standalone protocols or change any existing Lab store,
operator key, grant or source selection. The `v2` directory versions this
AlchLang implementation lane; it is not the legacy Define CLI v2 protocol.

## What executes in AlchLang

The actual session records and all their domain transitions execute through the
generated `Define.Execute` Operation. JavaScript does not contain a second
implementation of the question, meaning, revision or export decisions.

| Concept | Authored behavior |
| --- | --- |
| Session and scope | Preserve Project, Work, originating intent, goal, consumer and use; reject mismatched identity or revision. |
| Context | Retain the author's assessment, source snapshot and evidence; require sufficient context before questioning or export. |
| Questions and responses | Keep one question open, retain prompt and owner route, attribute answers/corrections and preserve deferral/refusal without inferring an answer. |
| Required concepts and handling | Explicit reuse, proposed meaning, open question, parameter application or meaning change. A disposition must name a declared concept. |
| Meanings | Carry statements, boundaries, parameters and JSON value schemas, ownership posture, revisions and original-byte lineage. |
| Applications | Preserve parameter values, provenance, exact meaning references, binding gaps and consumer/use. |
| Assessments | Preserve producer, reported result, method/evidence gaps and limits; never execute a reported assessment or promote its standing. |
| Definition materialization | Carry exact complete Definition/v2 and field-lineage bindings, identity intention, predecessor and owner route. |
| Candidate request | Construct a complete supported Pack v3 request from session data; refuse an open question or missing concept disposition. |
| Candidate confirmation | Record an exact package/request binding; later edits invalidate it. The CLI verifies the actual package before accepting confirmation. |
| Successor request | Require a higher explicit request revision and a predecessor binding; preserve prior Work history while starting the new draft. |
| Placement | Distinguish Work definitions, project authority definitions and upstream contributions. |
| Lab continuation | Preserve review/commit/refusal observations and require inspection before redispatching an unknown operation. |

Session revision and Pack request revision are separate. Each session command
advances the first. The author selects the second when initializing/importing a
request. Existing embedded meaning/application references retain their actual
Pack revision and digest; translation never silently rewrites those references.
Use an explicit successor request, with correctly bound references and predecessor
bytes, when revising an exported Pack. `import-request --successor` records that
transition in the same Work journal.

## The external bindings

AlchLang defines the data and decisions. Host mechanisms implement these ports:

| Port | Implementation |
| --- | --- |
| Shared Work records | [runtime.mjs](runtime.mjs) atomically publishes one `define/session.jsonl`, checks its hash chain and replays commands through generated AlchLang. |
| Exact JSON and protocol representation | [pack-port.py](pack-port.py) uses the existing strict Define decoder, maps typed union wrappers and UInt64 fields, and checks the actual request schema. |
| Capture, preparation, inspection, materialization and reconstruction | The unchanged [standalone Define implementation](../../standalone/README.md), through its existing API/CLI contracts. |
| Agent authoring | An agent supplies the typed command/proposal described by `AgentAuthoring`; it uses the same CLI command route as a person. Automatic language-model invocation is not installed by this package. |
| Native Lab operations | `define-alch lab ...` invokes the existing [explicit Lab connector](../../lab-integration/v1/README.md), including its actual source, grant, signature and head checks. |

The materialized Definition/v2 body is reused as an exact external carrier; its
complete schema is validated by its existing owner implementation. JSON Schema
and arbitrary application values are explicit `JsonText` fields in the AlchLang
model, decoded by the port. They are not discarded or represented by a Boolean.

Local author references and context assessments are declarations. They are not
verified human identities, agent delegation, semantic admission or native Lab
permission. A copied Work journal can reconstruct candidate authoring; it cannot
mint any of those authorities. Its hash chain detects inconsistent edits, not
malicious rewriting of an entirely unauthenticated history.

## Run the User Journey example

From the Lab root, choose an absent destination with an existing parent:

```bash
./define/define-alch build
./define/define-alch example --output /tmp/define-user-journey
./define/define-alch import-request \
  --work /tmp/define-user-journey/work \
  --file /tmp/define-user-journey/request.json \
  --context /tmp/define-user-journey/context.json \
  --project project:cyberalchemy-v2-to-lab-migration \
  --work-ref work:define-alch-user-journey \
  --actor person:local-author
./define/define-alch prepare \
  --work /tmp/define-user-journey/work \
  --source-root /tmp/define-user-journey/sources \
  --output /tmp/define-user-journey/package --permit-retention
./define/define-alch materialize \
  --package /tmp/define-user-journey/package \
  --output /tmp/define-user-journey/materialized
./define/define-alch reconstruct \
  --package /tmp/define-user-journey/package \
  --output /tmp/define-user-journey/restored
```

The example uses the actual repository User Journey candidate, original-file
SHA-256 `693045f6c86f0faa8b168d072e473bbb48f1e75cb71d440fc559c7440f147fe7`.
Its full body and source-linked attribution are retained. No native Lab owner
operation runs; the definition and the six product journeys keep their standing.
The example's context is explicitly authored candidate context, not a signed
current native Lab context.

`--permit-retention` asserts local rights for these selected sources. Without
it, the existing Define core preserves unresolved retention gaps. Existing output
destinations refuse overwrite. After uncertain publication, inspect the exact
output or command result before deciding whether another invocation is needed.

## Start and continue an authored conversation

`init --work DIRECTORY --file START.json --actor ACTOR` accepts this seed shape:

```json
{
  "session_id": "context-management-retention",
  "request_revision": "1",
  "request_lineage": {
    "predecessor_package_binding": null,
    "language_evidence_binding": null,
    "field_supplement_binding": null
  },
  "scope": {
    "project": "project:context-management",
    "work": "work:retention",
    "goal": "Define what an agent should retain",
    "originating_intent": "Preserve useful context between sessions",
    "context_description": "Candidate discovery in this Work",
    "consumer": "project-team",
    "intended_use": "inspect-preparation"
  },
  "validation_scope": {
    "required_checks": ["Exact sources and explicit boundaries"],
    "evidence_scope": "Authored candidate",
    "claim_ceiling": "No semantic acceptance or admission"
  }
}
```

People and agents submit commands with
`command --work DIRECTORY --file COMMAND.json`. Each command names its stable
ID, session/Project/Work, declared actor, exact expected session revision and a
typed payload. For example, after a sufficient `SetContext` command:

```json
{
  "command_id": "ask-retention-1",
  "session_id": "context-management-retention",
  "project": "project:context-management",
  "work": "work:retention",
  "actor": "person:author",
  "expected_revision": "2",
  "payload": {
    "tag": "Ask",
    "fields": {
      "value": {
        "question_id": "question:retention",
        "concept_id": "retention",
        "question": "What should the agent retain?",
        "owner_route": "role:work-author",
        "status": "Open"
      }
    }
  }
}
```

`show --work DIRECTORY` reconstructs the complete current session. `request`
exports the generated Pack request. `confirm` checks a real package against that
session and records its exact hashes; `Close` and `Resume` are explicit payloads.
`placement --scope Work|Project|Imported` and `lab-plan --file OBSERVATION.json`
execute the corresponding AlchLang decisions without publishing a definition or
performing a native effect. `sources` prints the complete authored `.alch` file.

## Work and storage

```text
work/<id>/
├── work.json                      # Project's existing Work carrier, if present
├── define/
│   ├── session.jsonl              # Authored commands and integrity/replay chain
│   └── definitions/               # Work-specific meanings, when selected
└── .local/
    └── define-session.lock/       # Only while a local command is committing

implementation/define-cli/alchlang/v2/.local/
└── build-*/                       # Rebuildable compiler output and diagnostics
```

The program writes only its journal and temporary lock under the selected Work;
it does not synthesize a canonical `work.json`, create a governed Project or
choose an authority registry. Journal file count stays constant as turns grow.
A clone with the same selected model can replay the journal without a database
migration. Git synchronization and conflicting team histories still require
explicit reconciliation; this is not a remote coordination service.

The journal is bounded to 10,000 commands and 64 MiB. Domain collections use the
explicit bounds in the source (24 concepts/parameters, 64 applications/assessments,
100 source/evidence/question entries). Requests beyond this lane's bounds refuse;
they are not truncated to fit. Pack JSON-schema limits can be wider. Compiler
outputs and diagnostic caches are ignored. Retained packages can live in external
artifact storage; this CLI's publication adapter writes the explicitly selected
local destination. No SQLite authority store or migrations are introduced.

Source changes require an explicit session-model successor/migration. The runtime
refuses to replay an old journal under silently changed AlchLang. Earlier
in-turn prototypes remain evidence under ignored `.local`; their obsolete storage
layout is refused rather than implicitly migrated or deleted.

## Verification

```bash
/home/vlad_/projects/cyberAlchemy-v2/.runtime/craft-release-2026-10-29/node-v26.12.1-linux-x64/bin/node \
  --test implementation/define-cli/alchlang/v2/tests/define.test.mjs
```

The tests use the generated Operation, actual filesystem publication, new CLI
processes and the real standalone API. They cover full request round trips,
answers/corrections/gaps, source and identity conflicts, replay and cloning,
exact User Journey materialization/reconstruction, local concurrent commands,
post-publication uncertainty and refusal of unsafe input.

[Recorded results](VERIFICATION.json) bind the authored implementation and test
bytes. Generation/review labels establish local compiler selection only; they do
not authenticate an owner or qualify deployment. The broader project/team and
native connector gaps from the six-journey audit remain separate work.
