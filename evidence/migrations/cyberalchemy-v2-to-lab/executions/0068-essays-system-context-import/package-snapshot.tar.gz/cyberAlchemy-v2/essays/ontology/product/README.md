# Essays Product Ontology

Private durable `business-domain` candidate for
`cav2.essays.product.business-domain.v1`.

The package projects only the already-authored node and relation IDs selected
by `cyberAlchemy-v2/essays/product-ontology.json`. Its meaning is bounded by the
exact adopted Essays Product Thesis and preserves product evidence gaps.

Materialize or check deterministically:

```bash
python3 cyberAlchemy-v2/essays/ontology/product/scripts/materialize.py --write
python3 cyberAlchemy-v2/essays/ontology/product/scripts/materialize.py --check
```

A passing check proves package closure and source currency only. The resulting
candidate still requires an exact owner review; it proves no product value,
implementation, publication, release, deployment, or external effect.
