# Essays Agent-runtime Authority/Security Ontology

Zero-authority candidate defining grants, leases, proposals, effect envelopes, protected credentials, revocation, expiry, and uncertain-effect reconciliation. Candidate authoring does not satisfy pending security/effect-owner gates. Owner approval is due only for the exact pre-merge candidate.
