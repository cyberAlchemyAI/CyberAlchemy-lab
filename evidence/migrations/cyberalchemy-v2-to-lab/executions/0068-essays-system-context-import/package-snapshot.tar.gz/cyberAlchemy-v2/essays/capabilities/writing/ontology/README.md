# Whisper-Derived Writing Capability Ontology

Private durable `business-domain` candidate for
`cav2.essays.writing-capability.business-domain.v1`.

The package projects the existing Essays writing-capability slice into five
views: intent to plan, plan to draft, review to revision, validation and
residue, and audience export. Whisper is retained as a source-owned candidate
partial realization. It is not made the Essays Product Capability by proximity.

The package makes the author-owned revision decision explicit. Addressable
review items can be accepted, rejected, deferred, or routed for alternatives;
the disposition is bound to the exact reviewed draft and constrains a later
revision proposal. It is not itself a prose mutation or publication authority.
The `review-to-revision` view exposes that boundary, while runtime conformance
remains explicit residue.

Materialize or check deterministically:

```bash
python3 cyberAlchemy-v2/essays/capabilities/writing/ontology/scripts/materialize.py --write
python3 cyberAlchemy-v2/essays/capabilities/writing/ontology/scripts/materialize.py --check
```

A passing check proves package closure and exact source currency only. Candidate
authoring and diagnostic compilation may continue without owner approval. The
Essays Project owner approves only the later exact pre-merge candidate, after
its changed bytes and validation evidence are frozen. This package grants no
ontology admission, implementation, publication, release, deployment, or
external effect.
