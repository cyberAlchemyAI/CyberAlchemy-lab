# Essays Agent-runtime Architecture Properties

Candidate architecture-property ontology for semantic consistency, durability and replay, client parity, capability isolation, effect safety, replaceability, and selected resource budgets. Empty observation projections preserve the pre-implementation evidence boundary.
