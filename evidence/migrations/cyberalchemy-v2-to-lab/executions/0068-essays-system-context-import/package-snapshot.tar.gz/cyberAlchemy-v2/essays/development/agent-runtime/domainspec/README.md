# Essays Agent-runtime DomainSpec Candidate

Authored DomainSpec v2 source for the first Essays runtime semantic vertical.
It binds the current candidate predecessor digests in `PREDECESSORS.json` and
models workspace identity, expected revisions, idempotent proposal custody,
Work Owner acceptance, supervised browser effects, and uncertain-effect
reconciliation.

`generated/` is diagnostic output from two in-memory invocations of the
existing DomainSpec v2 project loader. The script compares both serialized
graphs before publishing either generated artifact; the current receipt records
byte-identical output. This is construction evidence, not ontology admission,
implementation conformance, or merge approval.
