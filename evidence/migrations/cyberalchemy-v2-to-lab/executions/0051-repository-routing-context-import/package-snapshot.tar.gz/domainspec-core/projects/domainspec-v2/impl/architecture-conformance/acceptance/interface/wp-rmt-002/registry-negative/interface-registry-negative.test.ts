import {createHash} from "node:crypto";
import {existsSync,readFileSync} from "node:fs";
import {describe,expect,it} from "vitest";

const registryPath="projects/domainspec-v2/impl/architecture-conformance/factory/registry/factory-node-registry-v1.ts";
const providerPaths=[
  "projects/domainspec-v2/impl/architecture-conformance/factory/registry/providers/interface-typescript-v1.ts",
  "projects/domainspec-v2/impl/architecture-conformance/factory/registry/providers/interface-python-v1.ts",
  "projects/domainspec-v2/impl/architecture-conformance/factory/registry/providers/interface-rust-v1.ts",
];
const ids=["interface-typescript-v1","interface-python-v1","interface-rust-v1"];

describe("WP-RMT-002 Interface registry nonmembership",()=>{
  it("keeps all three direct provider IDs absent from the exact canonical snapshot",()=>{
    const bytes=readFileSync(registryPath);
    const text=bytes.toString("utf8");
    expect(createHash("sha256").update(bytes).digest("hex")).toBe("2497f2e047e023de2738bac4b815e6b0212560dcfc8053982c94f4a529a9f51b");
    expect(providerPaths.every(existsSync)).toBe(true);
    for(const id of ids) expect(text).not.toContain(id);
    expect(text).toContain("typescript-w3-effects-connections-v1");
  });
});
