# CyberAlchemy v2 Definitions Index

Status: active
Canonical source: [DEFINITIONS.md](DEFINITIONS.md)

## Terms

| ID | Term | Status | Canonical section | Plain-language intuition |
| --- | --- | --- | --- | --- |
| CAV2-D1 | stable repository | active | [Stable Repository](DEFINITIONS.md#cav2-d1-stable-repository) | The trustworthy base someone can download, understand, and build on without guessing what counts. |
| CAV2-D2 | source-ledgered amalgamation | active | [Source-Ledgered Amalgamation](DEFINITIONS.md#cav2-d2-source-ledgered-amalgamation) | An amalgamation with receipts. |
| CAV2-D3 | authority layer | active | [Authority Layer](DEFINITIONS.md#cav2-d3-authority-layer) | The document or surface allowed to count. |
| CAV2-D4 | source spine | active | [Source Spine](DEFINITIONS.md#cav2-d4-source-spine) | The starting bibliography with boundaries attached. |
| CAV2-D5 | promotion gate | active | [Promotion Gate](DEFINITIONS.md#cav2-d5-promotion-gate) | The point where the project asks whether a candidate is allowed to count now. |
| CAV2-D6 | stable repository stewardship | active | [Stable Repository Stewardship](DEFINITIONS.md#cav2-d6-stable-repository-stewardship) | The habit that keeps the repo understandable after the exciting part. |
| CAV2-D7 | authority import | active | [Authority Import](DEFINITIONS.md#cav2-d7-authority-import) | A shelf of candidates with labels. |
| CAV2-D8 | import candidate | active | [Import Candidate](DEFINITIONS.md#cav2-d8-import-candidate) | A domain's reusable idea can enter CAV2 review without surrendering its local meaning or authority. |
| CAV2-D9 | CyberAlchemy v2 | active | [CyberAlchemy v2](DEFINITIONS.md#cav2-d9-cyberalchemy-v2) | The home base: the repo you can download, trust, and build above. |
| CAV2-D10 | definition tower | active | [Definition Tower](DEFINITIONS.md#cav2-d10-definition-tower) | A stack of terms with a map, a boundary, and a next review step. |
| CAV2-D11 | tower space | active | [Tower Space](DEFINITIONS.md#cav2-d11-tower-space) | Where tower content comes from, lives, or gets worked on. |
| CAV2-D12 | Craft execution surface | active | [Craft Execution Surface](DEFINITIONS.md#cav2-d12-craft-execution-surface) | The workbench where the project remembers what is open and what happens next. |
| CAV2-D13 | authority promotion queue | active | [Authority Promotion Queue](DEFINITIONS.md#cav2-d13-authority-promotion-queue) | The review line for things that might be allowed to count. |
| CAV2-D14 | source space | active | [Source Space](DEFINITIONS.md#cav2-d14-source-space) | Where a candidate came from before CyberAlchemy v2 decides what to do with it. |
| CAV2-D15 | project space | active | [Project Space](DEFINITIONS.md#cav2-d15-project-space) | A room inside CyberAlchemy v2 with a declared job. |
| CAV2-D16 | typed coupling invariant | active | [Typed Coupling Invariant](DEFINITIONS.md#cav2-d16-typed-coupling-invariant) | If two things are wired together, draw the wire and label it. |
| CAV2-D17 | reflection tower method | active | [Reflection Tower Method](DEFINITIONS.md#cav2-d17-reflection-tower-method) | When the current floor cannot explain the leftover problem, build the next floor from that leftover problem and make it explain its way back down. |
| CAV2-D18 | residue | active | [Residue](DEFINITIONS.md#cav2-d18-residue) | The meaningful leftover: the part the current representation could not carry. |
| CAV2-D19 | ontology | active | [Ontology](DEFINITIONS.md#cav2-d19-ontology) | A map of meaning with typed links, receipts, and rules for use. |
| CAV2-D20 | Craft method | active | [Craft Method](DEFINITIONS.md#cav2-d20-craft-method) | CyberAlchemy's governed method for carrying product intent through exact realization, construction, independent checking, operation, recovery, evolution, and owner continuation without losing meaning or residue. |
| CAV2-D21 | four-facet action method | active | [Four-Facet Action Method](DEFINITIONS.md#cav2-d21-four-facet-action-method) | Before an action is allowed to matter, answer what kind it is, what shape governs it, how a human continues it, and how a machine checks it. |
| CAV2-D22 | orthogonal classification | active | [Orthogonal Classification](DEFINITIONS.md#cav2-d22-orthogonal-classification) | Do not add another label unless it tells the project something new. |
| CAV2-D23 | authority lifecycle axis | active | [Authority Lifecycle Axis](DEFINITIONS.md#cav2-d23-authority-lifecycle-axis) | Useful, trusted, finished, owned, and canonical are different words. |
| CAV2-D24 | provenance-first navigation | active | [Provenance-First Navigation](DEFINITIONS.md#cav2-d24-provenance-first-navigation) | Read the map before walking the whole city. |
| CAV2-D25 | schema amendment witness | active | [Schema Amendment Witness](DEFINITIONS.md#cav2-d25-schema-amendment-witness) | If the shape changes, leave a receipt and show what will catch mistakes. |
| CAV2-D26 | append-only event ledger | active | [Append-Only Event Ledger](DEFINITIONS.md#cav2-d26-append-only-event-ledger) | Record what happened as a new line; retries should not count twice. |
| CAV2-D27 | residue entropy | active | [Residue Entropy](DEFINITIONS.md#cav2-d27-residue-entropy) | The amount of meaningful distinction the current layer collapsed or left unnamed. |
| CAV2-D28 | value-cycle edge guard | active | [Value-Cycle Edge Guard](DEFINITIONS.md#cav2-d28-value-cycle-edge-guard) | If an edge can force a value and loop, stop and prove the loop is safe before it becomes a rule. |
| CAV2-D29 | axis orthogonality invariant | active | [Axis Orthogonality Invariant](DEFINITIONS.md#cav2-d29-axis-orthogonality-invariant) | Moving one slider should not secretly move another slider. If it does, name the wire between them. |
| CAV2-D30 | bounded recursive self-application | active | [Bounded Recursive Self-Application](DEFINITIONS.md#cav2-d30-bounded-recursive-self-application) | The system can use its own method on its own work, but each loop needs a label, a boundary, a reviewer, and a way back. |
| CAV2-D31 | primitive type | active | [Primitive Type](DEFINITIONS.md#cav2-d31-primitive-type) | A base kind the project is allowed to build with before it builds narrower things. |
| CAV2-D32 | method | active | [Method](DEFINITIONS.md#cav2-d32-method) | The repeatable way the project turns intent and evidence into work that can be checked, carried forward, and improved. |
| CAV2-D33 | definition | active | [Definition](DEFINITIONS.md#cav2-d33-definition) | The place where a term is finally allowed to mean something for this project. |
| CAV2-D34 | authority | active | [Authority](DEFINITIONS.md#cav2-d34-authority) | Who or what is allowed to make something count, and only for which purpose. |
| CAV2-D35 | provenance | active | [Provenance](DEFINITIONS.md#cav2-d35-provenance) | The receipt trail for where something came from and how it got here. |
| CAV2-D36 | traceability | active | [Traceability](DEFINITIONS.md#cav2-d36-traceability) | The thread from why this exists, to what changed, to what happens next. |
| CAV2-D37 | gate | active | [Gate](DEFINITIONS.md#cav2-d37-gate) | The checkpoint that says go, go with risk, stop, or route to the right owner. |
| CAV2-D38 | claim <= proof | active | [Claim-Proof Bound](DEFINITIONS.md#cav2-d38-claim-proof-bound) | Do not say more than the evidence can carry. |
| CAV2-D39 | intent | active | [Intent](DEFINITIONS.md#cav2-d39-intent) | What the work is trying to make possible before we know the final shape. |
| CAV2-D40 | challenge contract | active | [Challenge Contract](DEFINITIONS.md#cav2-d40-challenge-contract) | The object's "how to disagree with me correctly" field. |
| CAV2-D41 | authority model | active | [Authority Model](DEFINITIONS.md#cav2-d41-authority-model) | The traffic map for what is allowed to count, who can make it count, and what it must not be confused with. |
| CAV2-D42 | governed artifact tree | active | [Governed Artifact Tree](DEFINITIONS.md#cav2-d42-governed-artifact-tree) | A tree is allowed to organize serious work only after it shows who owns it, what it can prove, and how to disagree with it. |
| CAV2-D43 | pattern promotion lifecycle | active | [Pattern Promotion Lifecycle](DEFINITIONS.md#cav2-d43-pattern-promotion-lifecycle) | A pattern earns authority by working, being generalized, being challenged, and being accepted by the owner route. |
| CAV2-D44 | view-bearing concept | active | [View-Bearing Concept](DEFINITIONS.md#cav2-d44-view-bearing-concept) | Some ideas become important enough to need their own dashboard, but the dashboard still does not get to make the decision. |
| CAV2-D45 | UX/UI knowledge governance | active | [UX/UI Knowledge Governance](DEFINITIONS.md#cav2-d45-uxui-knowledge-governance) | Interface learning can become reusable knowledge without pretending that a nice-looking screen or passing browser test is automatically truth. |
| CAV2-D46 | experience evidence lifecycle | active | [Experience Evidence Lifecycle](DEFINITIONS.md#cav2-d46-experience-evidence-lifecycle) | A UI lesson becomes a rule only after it earns its way through evidence, repeat-use, challenge, and owner review. |
| CAV2-D47 | interface evidence boundary | active | [Interface Evidence Boundary](DEFINITIONS.md#cav2-d47-interface-evidence-boundary) | A browser can show what happened on the page; it cannot by itself prove what a human understood, trusted, felt, or preferred. |
| CAV2-D48 | authority promotion lifecycle | active | [Authority Promotion Lifecycle](DEFINITIONS.md#cav2-d48-authority-promotion-lifecycle) | Domains can teach the base, but reusable authority still requires cross-context evidence, challenge, CAV2 owner promotion, and separate version-exact adoption by each domain. |
| CAV2-D49 | closed authority-kind enumeration | active | [Closed Authority-Kind Enumeration](DEFINITIONS.md#cav2-d49-closed-authority-kind-enumeration) | The authority-kind list is closed in review mode: an unenumerated kind stays blocked until an owner decision adds it; deterministic enforcement remains pending. |
| CAV2-D50 | discipline | active | [Discipline](DEFINITIONS.md#cav2-d50-discipline) | A recurring cross-capability practice promoted via discipline-governance (steward + recurrence evidence + maturity ladder + hardening); evidence alone does not self-promote. Not a term/sigil/spell/task/work. |
| CAV2-D51 | canonical artifact | active | [Canonical Artifact](DEFINITIONS.md#cav2-d51-canonical-artifact) | A recognized artifact kind with one exact, allowed origin statement and an honest assurance level; none of those levels proves execution, truth, or authority. |
| CAV2-D52 | artifact durability | active | [Artifact Durability](DEFINITIONS.md#cav2-d52-artifact-durability) | Some documents are made to be used and retired (ephemeral, may hold contradictions); others to stand and be kept true (perennial, may not). |
| CAV2-D53 | axiom | active | [Axiom](DEFINITIONS.md#cav2-d53-axiom) | A foundational truth taken as given that a family of invariants and rules derives from — about the world the system is built around, not a rule the system obeys. |
| CAV2-D54 | invariant | active | [Invariant](DEFINITIONS.md#cav2-d54-invariant) | A must-hold condition on the system's own behavior; breaking it is a defect. The checkable "what must stay true" below the axiom and above the rulebook. |
| CAV2-D55 | premise | active | [Premise](DEFINITIONS.md#cav2-d55-premise) | A working proposition the project bets on before it's proven (`veracidade` low, `convicção` high) — expected to be promoted to axiom, revised, or retired as evidence comes in. |
| CAV2-D56 | schema | active | [Schema](DEFINITIONS.md#cav2-d56-schema) | The form the evidence must fit: what kinds may occur, what may go inside them, and how they may be wired together — and nothing about whether any of it is true, owned, or approved. |
| CAV2-D57 | exact publication authorization | active | [Exact Publication Authorization](DEFINITIONS.md#cav2-d57-exact-publication-authorization) | Owners approve the ingredients and limits first; a publisher later approves the exact finished bytes and destination. |
| CAV2-D58 | constitution | active | [Constitution](DEFINITIONS.md#cav2-d58-constitution) | An owner-scoped rulebook that governs matching subjects only after its exact version and scope are adopted. |
| CAV2-D59 | goal | active | [Goal](DEFINITIONS.md#cav2-d59-goal) | The future result one project is trying to reach, plus the evidence needed to say it was reached. |
| CAV2-D60 | project | active | [Project](DEFINITIONS.md#cav2-d60-project) | The stable identity that keeps related goals, owners, evidence, and work connected. |
| CAV2-D61 | research | active | [Research](DEFINITIONS.md#cav2-d61-research) | A bounded investigation that preserves its question, method, sources, evidence, and uncertainty without pretending the aggregate is the conclusion. |
| CAV2-D62 | experiment | active | [Experiment](DEFINITIONS.md#cav2-d62-experiment) | A bounded, recorded test that produces observations under declared conditions and claim limits. |
| CAV2-D63 | product thesis | active | [Product Thesis](DEFINITIONS.md#cav2-d63-product-thesis) | The durable product proposition that says why the product should exist, how it should create value, what it must protect, and what evidence could require revision. |
| CAV2-D64 | recursive instance ownership invariant | active | [Recursive Instance Ownership Invariant](DEFINITIONS.md#cav2-d64-recursive-instance-ownership-invariant) | The parent owns the blueprint, the local capability owns its instance, and the Project keeps their typed connection without letting either side silently rewrite the other. |
| CAV2-D65 | prototype-first DomainSpec construction invariant | active | [DomainSpec-Governed Construction Invariant](DEFINITIONS.md#cav2-d65-domainspec-governed-construction-invariant) | Prototype the words and ontology scaffolds, iterate the product through tests, approve the exact tested product, and only then request separate authority decisions. |
| CAV2-D66 | context | active | [Context](DEFINITIONS.md#cav2-d66-context) | The stable frame that says what work is about, why information is needed, and which Product, Project, Goal, consumers, subjects, and source policies apply. |
| CAV2-D67 | product capability | active | [Product Capability](DEFINITIONS.md#cav2-d67-product-capability) | What useful outcome the Product must make possible, kept separate from the tool or implementation that realizes it. |
| CAV2-D68 | person | active | [Person](DEFINITIONS.md#cav2-d68-person) | The human, not their login, job title, permission, or database row. |
| CAV2-D69 | team | active | [Team](DEFINITIONS.md#cav2-d69-team) | A named group working toward a purpose that remains recognizable when its members change. |
| CAV2-D83 | Operational Resilience | active | [Operational Resilience](DEFINITIONS.md#cav2-d83-operational-resilience) | Reconciled source voices; Craft ORODI admission. |
| CAV2-D84 | Operational Evidence | active | [Operational Evidence](DEFINITIONS.md#cav2-d84-operational-evidence) | Reconciled source voices; Craft ORODI admission. |
| CAV2-D85 | Evaluation Binding | active | [Evaluation Binding](DEFINITIONS.md#cav2-d85-evaluation-binding) | Reconciled source voices; Craft ORODI admission. |
| CAV2-D86 | Operational Evidence Evaluation State | active | [Operational Evidence Evaluation State](DEFINITIONS.md#cav2-d86-operational-evidence-evaluation-state) | Reconciled source voices; Craft ORODI admission. |
| CAV2-D87 | Failure Meaning Separation | active | [Failure Meaning Separation](DEFINITIONS.md#cav2-d87-failure-meaning-separation) | Reconciled source voices; Craft ORODI admission. |
| CAV2-D88 | Product Observability | active | [Product Observability](DEFINITIONS.md#cav2-d88-product-observability) | Reconciled source voices; Craft ORODI admission. |
| CAV2-D89 | Telemetry Conservation | active | [Telemetry Conservation](DEFINITIONS.md#cav2-d89-telemetry-conservation) | Reconciled source voices; Craft ORODI admission. |
| CAV2-D90 | Runtime Evidence | active | [Runtime Evidence](DEFINITIONS.md#cav2-d90-runtime-evidence) | Reconciled source voices; Craft ORODI admission. |
| CAV2-D91 | Deployment Evidence | active | [Deployment Evidence](DEFINITIONS.md#cav2-d91-deployment-evidence) | Reconciled source voices; Craft ORODI admission. |
| CAV2-D92 | Rollback Restoration Evidence | active | [Rollback Restoration Evidence](DEFINITIONS.md#cav2-d92-rollback-restoration-evidence) | Reconciled source voices; Craft ORODI admission. |
## Withdrawn Definition IDs

| Reserved ID range | Status | Successor authority |
| --- | --- | --- |
| `CAV2-D70`–`CAV2-D81` | withdrawn before ontology admission; do not reuse | [`KEP-D1`–`KEP-D12`](../../product/knowledge-exchange-protocol/authority/definitions/DEFINITIONS-INDEX.md) |

## Alias Lookup

| Alias | Definition ID |
| --- | --- |
| authority gate | CAV2-D5 |
| authority candidate | CAV2-D8 |
| authority import ledger | CAV2-D7 |
| authority model | CAV2-D41 |
| authority promotion queue | CAV2-D13 |
| authority routing model | CAV2-D41 |
| authority-kind closure | CAV2-D49 |
| closed authority-kind enumeration | CAV2-D49 |
| default-deny for unenumerated kinds | CAV2-D49 |
| scientific authority lifecycle | CAV2-D48 |
| promotion lifecycle | CAV2-D48 |
| authority surface | CAV2-D3 |
| canonical artifact | CAV2-D51 |
| typed artifact | CAV2-D51 |
| governed artifact instance | CAV2-D51 |
| process-origin-declared artifact | CAV2-D51 |
| process-born artifact | CAV2-D51 |
| non-canonical artifact | CAV2-D51 |
| artifact durability | CAV2-D52 |
| durability axis | CAV2-D52 |
| ephemeral artifact | CAV2-D52 |
| perennial artifact | CAV2-D52 |
| axiom | CAV2-D53 |
| foundational truth | CAV2-D53 |
| admitted principle | CAV2-D53 |
| bedrock commitment | CAV2-D53 |
| invariant | CAV2-D54 |
| must-hold constraint | CAV2-D54 |
| system invariant | CAV2-D54 |
| premise | CAV2-D55 |
| working premise | CAV2-D55 |
| working hypothesis | CAV2-D55 |
| hypothesis | CAV2-D55 |
| conviction bet | CAV2-D55 |
| schema | CAV2-D56 |
| structural declaration | CAV2-D56 |
| admissible-structure declaration | CAV2-D56 |
| shape declaration | CAV2-D56 |
| schema facet | CAV2-D56 |
| exact publication authorization | CAV2-D57 |
| two-step publication authorization | CAV2-D57 |
| source-owner release authorization | CAV2-D57 |
| exact-output publication approval | CAV2-D57 |
| private-by-default release | CAV2-D57 |
| architecture pattern promotion lifecycle | CAV2-D43 |
| artifact tree governance interface | CAV2-D42 |
| base repository | CAV2-D1 |
| base semantic object | CAV2-D31 |
| bootstrap source spine | CAV2-D4 |
| canonical definition | CAV2-D33 |
| challenge contract | CAV2-D40 |
| challenge_contract | CAV2-D40 |
| challenge response contract | CAV2-D40 |
| concept with governed view | CAV2-D44 |
| contestability contract | CAV2-D40 |
| Craft ledger surface | CAV2-D12 |
| Craft method | CAV2-D20 |
| Craft recursive method | CAV2-D20 |
| Craft surface | CAV2-D12 |
| CyberAlchemy base | CAV2-D9 |
| CyberAlchemy base repository | CAV2-D9 |
| CAV2 authority model | CAV2-D41 |
| CyberAlchemy stable repository candidate | CAV2-D9 |
| CyberAlchemy v2 project area | CAV2-D15 |
| definition | CAV2-D33 |
| definition unit | CAV2-D33 |
| definition promotion queue | CAV2-D13 |
| definition space | CAV2-D11 |
| downloadable base repository | CAV2-D1 |
| browser-evidence boundary | CAV2-D47 |
| explicit coupling invariant | CAV2-D16 |
| explicit typed relation rule | CAV2-D16 |
| experience evidence lifecycle | CAV2-D46 |
| experience knowledge governance | CAV2-D45 |
| external source space | CAV2-D14 |
| action facet obligations | CAV2-D21 |
| append-only ledger | CAV2-D26 |
| authority axis split | CAV2-D23 |
| altitude-bounded recursion | CAV2-D30 |
| axis orthogonality | CAV2-D29 |
| bounded recursivity | CAV2-D30 |
| constitution-first traversal | CAV2-D24 |
| constitution | CAV2-D58 |
| constitution artifact | CAV2-D58 |
| confidence lifecycle axis | CAV2-D23 |
| contract spec | CAV2-D37 |
| decision record | CAV2-D36 |
| deterministic event ledger | CAV2-D26 |
| governed discipline | CAV2-D50 |
| recurring-practice discipline | CAV2-D50 |
| discipline kind | CAV2-D50 |
| discipline practice | CAV2-D35 |
| entropy observable | CAV2-D27 |
| entropy readout | CAV2-D27 |
| edge contextuality guard | CAV2-D28 |
| edge non-contextuality guard | CAV2-D28 |
| event-sourced authority ledger | CAV2-D26 |
| four-facet action primitive | CAV2-D21 |
| graph-indexed lookup | CAV2-D24 |
| governed definition | CAV2-D33 |
| governed tree interface | CAV2-D42 |
| governed method | CAV2-D32 |
| governed action facet obligation | CAV2-D21 |
| governed action facet obligations | CAV2-D21 |
| governed action facets | CAV2-D21 |
| governed amalgamation | CAV2-D2 |
| import ledger | CAV2-D7 |
| local Craft surface | CAV2-D12 |
| local authority surface | CAV2-D3 |
| local project space | CAV2-D15 |
| load-bearing artifact tree | CAV2-D42 |
| load-bearing view concept | CAV2-D44 |
| method | CAV2-D32 |
| method primitive | CAV2-D32 |
| next stable repository | CAV2-D1 |
| non-orthogonality explicitness rule | CAV2-D16 |
| non-implied progress invariant | CAV2-D29 |
| governed constitution | CAV2-D58 |
| governed decision | CAV2-D36 |
| governed discipline | CAV2-D35 |
| governed meaning layer | CAV2-D19 |
| governed spec | CAV2-D37 |
| enforcement witness | CAV2-D25 |
| idempotent event ledger | CAV2-D26 |
| interface evidence boundary | CAV2-D47 |
| interface evidence lifecycle | CAV2-D46 |
| interface knowledge governance | CAV2-D45 |
| maturity-evidence-commitment split | CAV2-D23 |
| modular constitution | CAV2-D58 |
| ontology branch map | CAV2-D19 |
| ontology candidate | CAV2-D19 |
| ontology candidate condensation | CAV2-D19 |
| ontology map | CAV2-D19 |
| orthogonal-axis invariant | CAV2-D29 |
| orthogonal label discipline | CAV2-D22 |
| orthogonal ontology basis | CAV2-D22 |
| orthogonality | CAV2-D29 |
| owner decision | CAV2-D36 |
| owner gate | CAV2-D5 |
| owner-route model | CAV2-D41 |
| pattern authority lifecycle | CAV2-D43 |
| pattern promotion lifecycle | CAV2-D43 |
| process recursion | CAV2-D30 |
| primitive semantic type | CAV2-D31 |
| primitive type | CAV2-D31 |
| project authority model | CAV2-D41 |
| promoted spec artifact | CAV2-D37 |
| promotion queue | CAV2-D13 |
| provenance-first navigation | CAV2-D24 |
| recursive self-application | CAV2-D30 |
| recursivity | CAV2-D30 |
| recurring-practice artifact | CAV2-D35 |
| recursive ledger method | CAV2-D20 |
| resolved-choice artifact | CAV2-D36 |
| retrieval-entropy classification | CAV2-D22 |
| repository stewardship | CAV2-D6 |
| residue-carrying ledger method | CAV2-D20 |
| repeatable governance method | CAV2-D32 |
| reusable pattern promotion path | CAV2-D43 |
| rule promotion queue | CAV2-D13 |
| runtime witness | CAV2-D25 |
| schema amendment discipline | CAV2-D25 |
| schema-evolution witness | CAV2-D25 |
| semantic definition unit | CAV2-D33 |
| semantic primitive | CAV2-D31 |
| semantic primitive type | CAV2-D31 |
| session-as-provenance navigation | CAV2-D24 |
| source-indexed navigation | CAV2-D24 |
| status-evidence-commitment split | CAV2-D23 |
| reflection tower | CAV2-D17 |
| reflection-tower method | CAV2-D17 |
| residual remainder | CAV2-D18 |
| residue signal | CAV2-D18 |
| residue measure | CAV2-D27 |
| residue measurement | CAV2-D27 |
| residue climb | CAV2-D17 |
| residue escalation method | CAV2-D17 |
| semantic tower | CAV2-D10 |
| specification | CAV2-D37 |
| structure constitution | CAV2-D58 |
| source evidence space | CAV2-D14 |
| source-ledgered consolidation | CAV2-D2 |
| staged candidate | CAV2-D8 |
| stable repo | CAV2-D1 |
| stewardship discipline | CAV2-D6 |
| term tower | CAV2-D10 |
| tower-bearing space | CAV2-D11 |
| tower climb method | CAV2-D17 |
| typed coupling rule | CAV2-D16 |
| typed entropy observable | CAV2-D27 |
| typed residue | CAV2-D18 |
| taxonomy-schema-human-machine obligation | CAV2-D21 |
| contextuality tripwire | CAV2-D28 |
| UI learning lifecycle | CAV2-D46 |
| unpreserved structure | CAV2-D18 |
| unique-information classification | CAV2-D22 |
| UX evidence boundary | CAV2-D47 |
| UX evidence lifecycle | CAV2-D46 |
| UX/UI claim class boundary | CAV2-D47 |
| UX/UI governance interface | CAV2-D45 |
| UX/UI knowledge governance | CAV2-D45 |
| value-constraining cycle guard | CAV2-D28 |
| v2 consolidation surface | CAV2-D9 |
| view-bearing authority candidate | CAV2-D44 |
| view-bearing concept | CAV2-D44 |
| authority | CAV2-D34 |
| authority primitive | CAV2-D34 |
| normative authority | CAV2-D34 |
| decision authority | CAV2-D34 |
| provenance | CAV2-D35 |
| source provenance | CAV2-D35 |
| origin chain | CAV2-D35 |
| provenance chain | CAV2-D35 |
| source chain | CAV2-D35 |
| traceability | CAV2-D36 |
| traceable chain | CAV2-D36 |
| traceable linkage | CAV2-D36 |
| lifecycle traceability | CAV2-D36 |
| gate | CAV2-D37 |
| governance gate | CAV2-D37 |
| review gate | CAV2-D37 |
| decision gate | CAV2-D37 |
| admission gate | CAV2-D37 |
| claim <= proof | CAV2-D38 |
| claim-proof bound | CAV2-D38 |
| claim proof invariant | CAV2-D38 |
| contradiction review contract | CAV2-D40 |
| evidence-bounded claim | CAV2-D38 |
| proof-bounded claim | CAV2-D38 |
| intent | CAV2-D39 |
| human intent | CAV2-D39 |
| work intent | CAV2-D39 |
| governed intent | CAV2-D39 |
| source intent | CAV2-D39 |
| goal | CAV2-D59 |
| governed goal | CAV2-D59 |
| project goal | CAV2-D59 |
| outcome goal | CAV2-D59 |
| project | CAV2-D60 |
| governed project | CAV2-D60 |
| project identity | CAV2-D60 |
| work project | CAV2-D60 |
| research | CAV2-D61 |
| governed research | CAV2-D61 |
| project research | CAV2-D61 |
| research aggregate | CAV2-D61 |
| experiment | CAV2-D62 |
| governed experiment | CAV2-D62 |
| project experiment | CAV2-D62 |
| controlled experiment | CAV2-D62 |
| product thesis | CAV2-D63 |
| governed product thesis | CAV2-D63 |
| product commitment thesis | CAV2-D63 |
| product meaning thesis | CAV2-D63 |
| recursive instance ownership invariant | CAV2-D64 |
| instance ownership invariant | CAV2-D64 |
| recursive ownership invariant | CAV2-D64 |
| parent-instance ownership invariant | CAV2-D64 |
| model-instance ownership invariant | CAV2-D64 |
| capability instance ownership | CAV2-D64 |
| DomainSpec-governed construction invariant | CAV2-D65 |
| prototype-first DomainSpec construction invariant | CAV2-D65 |
| DomainSpec v2 construction invariant | CAV2-D65 |
| definitions-to-implementation construction invariant | CAV2-D65 |
| DomainSpec-first construction path | CAV2-D65 |
| CyberAlchemy construction pipeline | CAV2-D65 |
| context | CAV2-D66 |
| governed context | CAV2-D66 |
| work context | CAV2-D66 |
| product-work context | CAV2-D66 |
| governed product capability | CAV2-D67 |
| product behavior capability | CAV2-D67 |
| product capability | CAV2-D67 |
| person | CAV2-D68 |
| human individual | CAV2-D68 |
| team | CAV2-D69 |
| purpose-bound team | CAV2-D69 |

## Demoted Term Notes

| Term | Status | Normalization route | Do not treat as |
| --- | --- | --- | --- |
| Operational Ontology | demoted derived phrase under `CAV2-D19` + `CAV2-D23` | normalize typed meaning/relation/use obligations to D19, lifecycle posture axes to D23, and any concrete agent-operation obligation to a named object/relation/action/run/schema obligation. | primitive, peer ontology branch, standalone subtype, separate candidate term, or D23 alias. |

## Governance Notes

- Keep CyberAlchemy v2 terms local until a promotion route moves them outward.
- Reference Arcanum definition IDs for Arcanum-wide `contract` and `schema`
  semantics instead of redefining them here.
- Update [DEFINITION-DRIFT-AUDIT.md](DEFINITION-DRIFT-AUDIT.md) whenever a
  narrative artifact starts using these terms differently.
- A definition that asserts a record, tuple, field set, or structural contract
  in its formal voice carries a colocated `### Schema` section and a tracked row
  in [DEFINITION-SCHEMAS.md](DEFINITION-SCHEMAS.md). `CAV2-D23` is tracked; the
  remaining schema-bearing definitions are queued in that registry's backlog.
