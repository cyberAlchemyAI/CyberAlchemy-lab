export interface Customer {
  "customerId": string;
  "riskScore": number;
  "status": string;
  "amount": number;
}
