export const workflowContracts = [] as const;
