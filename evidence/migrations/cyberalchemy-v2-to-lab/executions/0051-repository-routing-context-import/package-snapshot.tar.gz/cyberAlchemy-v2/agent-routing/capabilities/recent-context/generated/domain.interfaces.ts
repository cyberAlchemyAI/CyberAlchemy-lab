export const interfaceContracts = [] as const;
