export const stateMachines = [
  {
    "subject_ref": "Commit",
    "states": [],
    "transitions": []
  },
  {
    "subject_ref": "ChangedFile",
    "states": [],
    "transitions": []
  },
  {
    "subject_ref": "ProjectScope",
    "states": [],
    "transitions": []
  },
  {
    "subject_ref": "RecentView",
    "states": [],
    "transitions": []
  }
] as const;
