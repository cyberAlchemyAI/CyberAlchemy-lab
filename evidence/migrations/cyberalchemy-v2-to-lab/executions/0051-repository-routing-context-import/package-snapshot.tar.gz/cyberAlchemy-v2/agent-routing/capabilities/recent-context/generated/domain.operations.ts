export const operationContracts = [] as const;
