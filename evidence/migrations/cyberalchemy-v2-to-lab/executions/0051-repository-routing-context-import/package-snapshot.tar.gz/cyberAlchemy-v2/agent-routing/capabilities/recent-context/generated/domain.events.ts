export const eventContracts = [] as const;
