# Owner intent: reasoning and context management

Recorded: 2026-08-31

The product owner directed that the Agent Reasoning Engine become the
CyberAlchemy-v2 system for both reasoning and context management, rooted at
`cyberAlchemy-v2/development/agent-reasoning-engine`, and requested that it be
made first class with its own ontology.

This construction interprets that direction as one stable Product Capability:

> Enable CyberAlchemy-v2 to assemble and maintain a bounded, provenance-bearing
> reasoning context; derive a typed semantic judgment from that context; expose
> residue and invalidation; and keep every result non-authorizing until a
> separate owner gate permits an exact effect.

The direction expands the candidate whole-engine meaning. It does not backdate
context-management behavior into the existing semantic evaluator or intent
route resolver, widen the bounded L0 promotion, admit a DomainSpec profile or
system ontology, accept an implementation binding, prove conformance, or grant
publication, release, deployment, or effect authority.

## Fast routing and decision-gate refinement

Recorded: 2026-09-01

The product owner further directed that request routing must be fast and must
select the nearest applicable CyberAlchemy-v2 capability from the request
context. Goal is one capability, not a universal wrapper. Its profile must be
retained as exact provenance whenever Goal is evaluated or selected.

After each completed operation, the engine must evaluate the proposed
continuation against the authority model and governance invariants. A sole
non-consequential continuation may proceed. Multiple admissible choices or a
consequential, protected, irreversible, authority-changing, publishing,
deploying, destructive, credential, spend, or external-effect choice must stop
at a configurable Decision Gate. Zero admissible continuations block, and no
continuation completes the request.

The configuration may classify and route a decision, but it cannot adopt a
governance rule, supply owner consent, or authorize the selected effect.
