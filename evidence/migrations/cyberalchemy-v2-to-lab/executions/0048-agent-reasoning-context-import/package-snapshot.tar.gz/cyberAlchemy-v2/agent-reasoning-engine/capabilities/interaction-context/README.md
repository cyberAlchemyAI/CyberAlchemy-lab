# Manage Interaction Context

Registered prototype child capability of ARE. Product identity lists its exact capability ID. The parent capability remains unchanged.

Construction and open questions: [full-loop plan](../../../development/agent-reasoning-engine/planning/interaction-context/full-loop/PLAN.md). No operational authority.
