# Are Continuous Construction Task Loop Specification

Generated human view. Canonical semantics live in the project-local machine sources.
Graph digest: `b68127b39574d4cec31e7ca69b19ecd64a7b50e790d78ec46cec1a88918db9ff`.

## Nodes

| Node | Kind | Intent |
| --- | --- | --- |
| `are-continuous-construction-task-loop.CompletedTurnEvidence` | Entity | Bind one mechanism-observed completed ARE turn to exact thread, turn, construction, C19 attempt, request-context, and evidence-manifest identities before construction continuation is evaluated. |
| `are-continuous-construction-task-loop.ComposedContinuationDecision` | Entity | Return one deterministic no-effect result that proposes a direct exact successor only under dual permission and otherwise preserves the stricter parent boundary. |
| `are-continuous-construction-task-loop.ConstructionAttemptSnapshot` | Entity | Bind the exact immutable C19 program, evaluator, and bounded-attempt bytes used for one composed decision. |
| `are-continuous-construction-task-loop.ExactNextStageInvariant` | Rule | Permit a direct proposal only when ARE matches the completed thread and turn, C19 matches its bound construction attempt, C19 is CONTINUE, ARE is direct, both parent decisions are no-effect, and both name the exact first applicable pending D65 stage. |
| `are-continuous-construction-task-loop.HumanBoundaryInvariant` | Rule | Keep readiness for human testing and a request for terminal confirmation distinct, start no successor for either, and never infer a human decision from a passing packet or observation. |
| `are-continuous-construction-task-loop.ParentDecisionPair` | Entity | Preserve the ARE continuation assessment and C19 evaluation as separate immutable parent decisions with their own digests and meaning owners. |

## Edges

| Edge | From | Type | To |
| --- | --- | --- | --- |

This file is generated; edit machine sources and rebuild.
