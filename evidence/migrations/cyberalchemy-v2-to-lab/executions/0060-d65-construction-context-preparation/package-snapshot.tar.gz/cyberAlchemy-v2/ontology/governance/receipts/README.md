# Governance ontology validation receipts

Receipts in this directory are append-only validation snapshots emitted by
`../scripts/validate.py --write-receipt`. Their material digest identifies the
validated package snapshot only. It is not semantic identity, lifecycle state,
authority, adoption, or enforcement evidence.
