# Governance D65 Construction Specification

Generated human view. Canonical semantics live in the project-local machine sources.
Graph digest: `cc8a0ad6af78f1f5b562d87b1674b3e1837262efde593e92b6d8b2bdb4cd603a`.

## Nodes

| Node | Kind | Intent |
| --- | --- | --- |
| `governance-d65-construction.ConstructionBinding` | Entity | Preserve one stable construction identity across exact definitions, product meaning, DomainSpec source, derived system ontology, implementation binding, and conformance evidence. |
| `governance-d65-construction.DomainSpecGovernedConstructionInvariant` | Rule | Return true only when every predecessor required by the claimed construction stage is exact, current, validated, reproducible, owner-accepted where required, and non-effectful as a validation result. |

## Edges

| Edge | From | Type | To |
| --- | --- | --- | --- |

This file is generated; edit machine sources and rebuild.
