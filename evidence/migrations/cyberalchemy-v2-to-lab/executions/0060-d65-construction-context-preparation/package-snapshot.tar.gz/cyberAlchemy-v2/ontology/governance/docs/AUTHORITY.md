# Governance Authority And Effects

Status: perennial candidate. No authority or enforcement effect.
Owners: CyberAlchemy v2 authority owner and Governance product ontology owner.

In plain terms: this is a long-lived authority-boundary proposal. It appoints
no owner and grants no permission.

## Purpose

Governance becomes dangerous when evidence, checks, ownership, adoption, and
permission blur together. This document states who owns each kind of movement
and what the candidate module itself cannot do.

Canonical authority meaning remains owned by CAV2-D34 and the CyberAlchemy v2
Authority Model. This document specializes that meaning for the Governance
module without replacing it.

## Authority Model

Authority is the bounded right to make one particular consequence count. An
authority envelope must identify:

```text
holder + action + target + scope + conditions + lifecycle point + effect
```

A Governance Authority record represents that envelope. Its presence in the
ontology does not prove the envelope is valid. The exact source, holder, scope,
effect, conditions, and current validity must be established separately.

Authority scopes every concept and relation that may matter to a real movement.
It is not merely the last step of a graph.

## Owners And Decision Rights

| Matter | Owner | May decide | Cannot decide through this role alone |
| --- | --- | --- | --- |
| Candidate product meaning | Governance product ontology owner | Product thesis, actors, capabilities, outcomes, and business-rule proposals. | Canonical definitions, rule adoption, or runtime acceptance. |
| Candidate governance domain model | Governance-model owner | Candidate concept mappings, typed relations, bindings, and residue. | Canonical CAV2 meaning or real governance effects. |
| Canonical authority meaning | CyberAlchemy v2 authority owner | Authority vocabulary and source posture. | Another owner's product behavior or runtime implementation. |
| Governance portfolio | Governance Steward | Inventory, coherence review, conflict discovery, health reporting, and owner routing for one declared portfolio. | Source meaning, owner decisions, rule adoption, or enforcement. |
| Source rule | Source rule owner | Rule statement, semantic version, source scope, and source-local status. | Constitution adoption or cross-repository enforcement. |
| Evidence and evaluation | Governance evidence owner | Exact evidence selection, observation provenance, calculation version, findings, gaps, and claim ceiling. | Rule lifecycle, applicability by assertion, or owner decision. |
| Independent observation | Independent Observer | One bounded observation, causal posture, missing evidence, privacy boundary, and explanation. | Governance verdict, decision, adoption, execution, or effect. |
| Governance decision | Decision owner | One exact keep, revise, decline, or adoption choice within owned scope. | Effects outside the recorded authority envelope. |
| Constitution | Constitution owner | Exact members, selectors, scope, and adoption record. | Runtime attachment or external enforcement without a separate binding. |
| Validation or enforcement binding | Validator Or Enforcer owner | Deterministic input, evaluation, result, and integration contract for one accepted binding. | Source governance meaning, applicability outside the binding, owner choice, or broader effects. |
| Runtime | Future governance enforcement runtime owner | One exact implementation and operational contract after acceptance. | Product meaning, canonical definitions, or rule adoption. |
| Public extraction | CyberAlchemy v2 public/private boundary owner | Exact public-safe targets and release boundary. | Publication of unreviewed private content. |

Documents may describe these routes. They cannot appoint the people or make the
decisions.

## Evidence And Decision Boundary

Evidence supports an assessment. An observation records that something
happened. A calculation produces an assessment. A policy supplies a
recommendation strategy.

None of those is a Governance Decision.

A validation PASS proves only that declared checks passed for selected bytes or
records. It does not prove business correctness, product value, owner
acceptance, rule fitness, authority, or permission.

## Constitution And Enforcement Boundary

A Governance Constitution is an exact owner-adopted and selector-bound
rulebook. Candidate, present, selected, context-loaded, or validated artifacts
are not active merely because they exist.

Even an adopted Constitution does not enforce itself. A consequential effect
also requires:

1. an exact adopted rule or policy member;
2. an applicable subject and attempted consequence;
3. a valid authority envelope;
4. an explicit enforcement binding;
5. a selected runtime integration; and
6. a result contract for allow, deny, abstain, or error.

The `GOV-INV-CAV2-D64` registration and
`GOV-RULE-D64-BINDING-COMPLETE` review rule satisfy none of those adoption or
enforcement preconditions. The canonical definition is active, but its ontology
registration is candidate and its operational rule is explicitly not adopted.
Presence, source status, schema validity, or a review outcome cannot change
that posture.

This candidate package supplies none of those runtime effects.

## Effect Ceiling

The current module, both ontologies, their bindings, documents, schemas,
validators, and receipts carry:

```text
authority_effect: none
enforcement_effect: none
implementation_effect: none
```

They may explain and validate structure. They may not adopt, activate, block,
permit, publish, deploy, or execute work.

## CyberAlchemy Host Boundary

The module is structurally autonomous inside the private CyberAlchemy v2 tree.
It references canonical CAV2 and DomainSpec sources through exact selectors.
It does not depend on the CyberAlchemy-wide product ontology for its internal
business meaning.

`module_of` records host context only. It does not merge product identity,
authority, lifecycle, release state, or public/private posture.

## Challenge And Correction

A participant may challenge:

- a concept mapping;
- rule statement or rule kind;
- harm or risk basis;
- evidence source or observation classification;
- assessment result or policy recommendation;
- owner route;
- Constitution membership or scope;
- authority envelope;
- product binding; or
- claimed runtime effect.

The challenged item remains candidate, open, non-current, or not evaluable as
appropriate until the responsible owner resolves it. A challenge is evidence,
not a veto or automatic decision.

## Example

Example only: no real authority is granted.

A validator finds that a proposed action violates a candidate rule. The result
is diagnostic evidence only. Unless an owner-adopted Constitution contains the
exact rule, a valid authority envelope covers the consequence, and a selected
runtime binding says the validator may affect that result, the finding cannot
block or permit the action.

## Claim Ceiling

This document explains candidate owners and effect boundaries. It grants no
role, permission, authority, adoption, activation, acceptance, execution,
publication, release, deployment, or external effect.
