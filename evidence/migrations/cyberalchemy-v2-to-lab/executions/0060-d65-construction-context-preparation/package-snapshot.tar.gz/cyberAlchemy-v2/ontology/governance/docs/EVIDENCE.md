# Governance Evidence, Observation, And Evaluation

Status: perennial candidate. No authority or enforcement effect.
Owner: Governance evidence owner.

In plain terms: this is a long-lived evidence proposal. It does not prove that
a rule is good, harmful, necessary, applicable, enforceable, or removable.

## Purpose

Governance must explain what it protects, how it applies, whether it works,
what burden it creates, where authority resides, and what is still unknown.
This document defines evidence contracts across the whole Governance product,
not only task lifecycle or refresh episodes.

Evidence supports evaluation, decisions, validation, enforcement results,
observation, audit, explanation, and owned improvement. It never supplies
authority merely by existing.

## Evidence Model

The product separates:

- **Governance Basis Evidence** — an exact source for the invariant, harm,
  risk, obligation, or authority boundary that motivates a control;
- **Applicability Evidence** — facts used to decide whether selected governance
  matches an exact subject and circumstance;
- **Authority Evidence** — a reference to an owned authority envelope,
  delegation, decision, or adoption record;
- **Validation Evidence** — deterministic inputs, checks, outputs, and
  missing-input behavior for a non-effectful evaluation;
- **Enforcement Evidence** — the exact adopted binding, execution inputs,
  verdict, and result provenance for a governed consequence;
- **Governance Observation** — a bounded past occurrence about governance
  behavior, burden, drift, failure, or outcome;
- **Governance Evaluation** — a no-effect synthesis of basis, applicability,
  coherence, effectiveness, burden, observations, and gaps; and
- **Governance Decision** — a separately owned choice that may accept, reject,
  defer, override, or act on a recommendation.

Evidence is not automatically true, complete, causal, current, applicable, or
authoritative. A passing validation is not adoption or permission. A denial is
not proof that the underlying governance is well designed.

## Harm And Risk Basis

The candidate product rule is:

> Governance must name the invariant, harm, material risk, obligation, or
> authority boundary it protects.

The basis may be inherited from an owned axiom, Constitution, statutory or
contractual obligation, safety argument, prior incident, or bounded risk
analysis. Every rule does not need an invented rule-local incident, but its
basis and evidence posture must be traceable.

When the basis is absent or insufficient for the requested claim, the result is
`not_evaluable` or a narrower claim. It does not prove the rule invalid and
does not authorize removal.

DomainSpec v1 Axiom A6 provides one repository precedent: governance competes
for finite cognitive and instruction bandwidth, and low-yield rules should be
reviewed. Its cited harms do not become current measured findings merely by
being referenced.

## Observation Contract

A durable Governance Observation should include:

- observation identity and occurred-at time;
- exact subject and bounded context;
- typed behavior, outcome, failure, burden, or drift class;
- source, witness, collection method, and provenance;
- relevant governance and executable versions;
- known causal status and competing explanations;
- privacy, retention, and access posture;
- missing or excluded evidence; and
- claim ceiling.

Observation must remain independent from execution and owner decision. Unknown
causes stay unknown. Missing evidence cannot be silently classified to
complete a metric or verdict.

## Assessment Contract

One Governance Evaluation should name:

- the exact governance object and semantic version;
- the requested evaluation question and claim ceiling;
- invariant, harm, risk, obligation, or authority basis;
- applicability scope and matching evidence;
- included and excluded evidence with reasons;
- control-effectiveness and failure indicators;
- authority and ownership evidence where relevant;
- burden and friction indicators;
- contradictions, conflicts, attenuation, and counterevidence;
- missing-data and `not_evaluable` behavior;
- evaluability status; and
- optional recommendation plus its required owner route.

Candidate recommendation vocabulary may include `keep`, `harden`, `simplify`,
`merge`, `correct`, `attenuate`, `supersede`, `retire`, or `defer`. A
recommendation performs none of those verbs.

## Friction Measures

Friction is one of six product measurement families, alongside governance
coverage, control effectiveness, authority legibility, refresh churn, and
governance learning effectiveness.

A friction contract should define:

- the bounded work and event population;
- time, interruption, handoff, duplicate-work, exception, and coordination
  indicators;
- attribution and competing-cause rules;
- included and excluded events;
- privacy and missing-data behavior;
- baseline, window, and unit; and
- protection countermeasures.

**Governance Refresh Churn** is one candidate indicator:

```text
refreshes attributed to currentness or lifecycle mechanics
----------------------------------------------------------
          bounded work objectives observed
```

Semantic scope changes, owner decisions, and requested redesign are excluded.
No numeric target or KPI is adopted. The measure cannot stand alone; it must be
paired with missed-drift, false-block, false-allow, or control-effectiveness
evidence so reducing refreshes cannot silently weaken governance.

## Missing Evidence

Missing evidence must remain visible. Depending on the requested claim, it may
produce:

- `not_evaluable`;
- a narrower or conditional finding;
- a request for a specific witness or measurement;
- a conflict or attenuation finding;
- a route to the evidence, governance, or decision owner; or
- a stop before a consequence when an adopted control requires fail-closed
  behavior.

It must not produce invented observations, assumed PASS, inferred owner choice,
implicit applicability, automatic retirement, or fabricated causal certainty.

The reported seven-refresh experience remains a motivating candidate
observation until a typed event population exists. It does not define the
product or establish a metric result.

## Privacy And Retention

Evidence collection should be purpose-limited. Prefer bounded subject IDs,
typed causes, counts, technical provenance, and exact decision or binding
references. Do not collect private conversation content or infer cognitive,
emotional, or attentional state unless a separately authorized product need,
consent model, and retention contract exist.

Each evidence class needs an owner, access boundary, retention period,
correction route, and deletion or preservation obligation. This candidate does
not approve a telemetry store or retention schedule.

## Example

Example only: no real governance or publication action is changed.

A publication validator denies an action because exact authorization is
missing. The enforcement evidence can establish which binding, inputs, and
verdict were used. It cannot prove the publication rule is proportionate.
Repeated false blocks may become observations, but a fitness evaluation must
also inspect applicability, authority clarity, protection outcomes, competing
causes, and missing events. Any recommendation then routes to the responsible
owner and remains non-effectful.

A digest may prove the evaluated bytes. It cannot prove why the rule exists,
whether it applies, who may decide, or whether the rule should change.

## Claim Ceiling

This document describes candidate evidence, observation, evaluation, and
measurement contracts. It proves no harm, causality, applicability, current
burden, metric result, KPI, control effectiveness, rule fitness, recommendation
correctness, owner decision, authority, or permission to change governance.
