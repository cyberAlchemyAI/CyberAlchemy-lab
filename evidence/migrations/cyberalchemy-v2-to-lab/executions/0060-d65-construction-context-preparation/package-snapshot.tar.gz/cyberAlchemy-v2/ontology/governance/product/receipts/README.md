# Validation Receipts

Validation receipts are append-only evidence for exact package snapshots. They
do not carry product, authority, adoption, enforcement, publication, or runtime
conformance authority.
