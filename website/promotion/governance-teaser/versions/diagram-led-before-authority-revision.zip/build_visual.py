"""Rebuild the editable, diagram-led LinkedIn teaser. No publication effects."""
from pathlib import Path
from html import escape
import re

ROOT = Path(__file__).resolve().parent

def icon(name):
    return f'<img src="assets/{name}.svg" alt="" aria-hidden="true">'

def slide(number, cls, title, body, label, case=True):
    footer='Northstar · illustrative incident' if case else 'CyberAlchemy Lab · website preview'
    return f'''<div class="frame"{' hidden' if number>1 else ''}><section class="slide {cls}" aria-labelledby="slide-{number}">
<header><img class="logo" src="assets/logo.svg" alt="CyberAlchemy Lab"><span>{label}</span></header>
<h{'1' if number==1 else '2'} id="slide-{number}">{title}</h{'1' if number==1 else '2'}>
{body}<footer><span>{footer}</span><span>{number:02d} / 08</span></footer></section></div>'''

lens_icons=''.join(f'<span class="{key}">{icon(asset)}<b>{label}</b></span>' for key,asset,label in [('authority','book-open','Authority'),('provenance','route','Provenance'),('lifecycle','refresh-cw','Lifecycle')])
slides=[]
slides.append(slide(1,'cover','Permission is<br>one part of<br>AI governance.',f'''<img class="cover-orb" src="assets/orb.webp" alt=""><p class="cover-lead">CyberAlchemy Lab also governs<br>meaning, evidence and change.</p><div class="cover-lenses">{lens_icons}</div>''','A first look inside the Lab',False))

dots=''.join(f'<circle cx="{31+(i%10)*61}" cy="{28+(i//10)*47}" r="14" fill="{("#bc4e40" if i>=49 else "#245fbd")}"/>' for i in range(50))
slides.append(slide(2,'incident','“The export is<br>missing records.”',f'''<p class="scope-line">Northstar · status = active · fixed snapshot S1</p>
<div class="count-flow"><div>{icon('database')}<strong>10,000</strong><span>required IDs from S1</span></div><div class="compare-arrow"><span>compare<br>identifiers</span><b>→</b></div><div>{icon('briefcase-business')}<strong>9,800</strong><span>IDs in output E12</span></div></div>
<figure class="coverage"><svg viewBox="0 0 620 250" role="img" aria-labelledby="coverage-title coverage-desc"><title id="coverage-title">Required identifier coverage</title><desc id="coverage-desc">Each dot represents 200 required IDs. Forty-nine blue dots are present in E12. One coral dot is missing, representing 200 missing required identifiers.</desc>{dots}</svg><figcaption><span class="present-dot"></span> Present <span class="missing-dot"></span> Missing <small>Each dot = 200 required IDs</small></figcaption></figure>
<p class="result-line"><b>200 missing IDs.</b> Cause unresolved.</p>''','The incident'))

slides.append(slide(3,'authority-page','Authority gives<br>the work a basis.',f'''<div class="diagram vertical authority-flow" role="img" aria-label="An owner-accepted definition governs the agent’s completeness comparison. Current permission governs which investigation actions it may perform. These authorities have separate roles.">
<div class="node authority-node"><div class="node-label authority">{icon('book-open')}Owner-accepted definition · v1</div><p>For S1, Northstar and status = active,<br>every required ID must appear in E12.</p></div>
<div class="connector authority"><span>governs the comparison</span><b>↓</b></div>
<div class="agent-node">{icon('bot')}<strong>Agent investigates the export</strong></div>
<div class="connector authority"><b>↑</b><span>sets the action scope</span></div>
<div class="permission-node"><span>Current permission</span><p>Inspect · compare · propose a repair</p></div></div>
<p class="takeaway">Accepted meaning and permission do different jobs.</p>''','Authority'))

slides.append(slide(4,'provenance-page','Show how the<br>finding was produced.',f'''<div class="diagram source-trail" role="img" aria-label="Fixed snapshot S1 for Northstar and its active-status filter and saved output E12 feed comparison method version 2. Session 12 records the result: 200 required IDs missing. The comparison supports the omission claim, while its cause remains unknown.">
<div class="source-pair"><div class="source-node">{icon('database')}<strong>Snapshot S1</strong><span>Account + filter<br>10,000 required IDs</span></div><div class="source-node">{icon('briefcase-business')}<strong>Output E12</strong><span>Saved export<br>9,800 IDs</span></div></div>
<svg class="join" viewBox="0 0 920 105" preserveAspectRatio="none" aria-hidden="true"><path d="M210 0V43H710V0M460 43V99"/><path d="m448 87 12 12 12-12"/></svg>
<div class="method-node"><strong>Identifier comparison · method v2</strong><span>Recorded by session 12</span></div>
<div class="connector provenance"><span>produces the observation</span><b>↓</b></div>
<div class="observation-node"><strong>200</strong><span>required IDs missing from E12</span></div></div>
<p class="takeaway">Keep the inputs, method and recorder with the result.</p>''','Provenance'))

slides.append(slide(5,'lifecycle-page','A proposed repair<br>has steps ahead.',f'''<div class="diagram repair-route" role="img" aria-label="The current repair revision 8 is a candidate. Review of evidence and an owner decision are needed before acceptance. Putting an accepted implementation into use has a separate activation authorization. The future stages shown are conditional, not completed incident outcomes.">
<div class="state-node current"><span class="stage-label">NOW</span><strong>Repair r8 · candidate</strong></div>
<div class="connector lifecycle"><span>evidence review + owner decision</span><b>↓</b></div>
<div class="state-node conditional"><span class="stage-label">IF ACCEPTED</span><strong>Accepted revision</strong></div>
<div class="connector lifecycle"><span>separate authority for activation</span><b>↓</b></div>
<div class="state-node conditional activation"><span class="stage-label">IF ACTIVATED</span><strong>Implementation in use</strong></div></div>
<p class="takeaway">Acceptance and activation remain separate.</p>''','Lifecycle'))

slides.append(slide(6,'continuity','Temporary agents.<br>Durable project state.',f'''<div class="diagram continuity-diagram" role="img" aria-label="Session 12 records work in durable project state. At session end its short-term notes clear. A later session starts with fresh working memory and receives prepared context and ontology views from project state. It resumes only with usable context and current permission.">
<div class="session-pair"><div>{icon('bot')}<strong>Session 12</strong><span>Working notes clear<br>at session end</span></div><div>{icon('bot')}<strong>New session</strong><span>Fresh working<br>memory</span></div></div>
<div class="memory-arrows"><div><span>Record work</span><b>↓</b></div><div><span>Prepare context<br>+ ontology views</span><b>↑</b></div></div>
<div class="durable-state">{icon('database')}<strong>Shared project state</strong><div class="saved-records"><span>Definition v1</span><span>Sources S1 / E12</span><span>Finding: 200 missing</span><span>Repair r8: candidate</span></div></div></div>
<p class="resume-line"><b>Task view v3 expired → pause.</b><br>Resume with a usable view and current permission.</p>''','Continuity across sessions'))

slides.append(slide(7,'connected','Three lenses.<br>One incident.',f'''<div class="diagram triangle" role="img" aria-label="Authority, provenance and lifecycle all apply to the same Northstar investigation. Authority supplies accepted meaning and current permission. Provenance traces inputs S1 and E12, method version 2 and session 12. Lifecycle tracks the candidate repair and expired task view. The finding is 200 missing IDs; its cause remains unresolved.">
<svg viewBox="0 0 920 770" aria-hidden="true"><path class="authority-path" d="M200 205C200 245 364 235 364 288"/><path class="provenance-path" d="M720 205C720 245 556 235 556 288"/><path class="lifecycle-path" d="M460 570V550"/><path class="authority-path" d="m354 273 10 15 10-15"/><path class="provenance-path" d="m546 273 10 15 10-15"/><path class="lifecycle-path" d="m450 565 10-15 10 15"/></svg>
<div class="lens-node authority">{icon('book-open')}<strong>Authority</strong><span>Accepted definition v1<br>Current permission</span></div>
<div class="lens-node provenance">{icon('route')}<strong>Provenance</strong><span>S1 / E12 · method v2<br>Session 12</span></div>
<div class="incident-hub"><strong>Northstar<br>investigation</strong><span>200 IDs missing<br>Cause unresolved</span></div>
<div class="lens-node lifecycle">{icon('refresh-cw')}<strong>Lifecycle</strong><span>Repair r8: candidate<br>Task view v3: expired</span></div></div>''','The connected model'))

slides.append(slide(8,'release','Inside an open<br>company brain.',f'''<img class="release-orb" src="assets/orb.webp" alt=""><p class="release-intro">CyberAlchemy Lab</p><div class="release-lenses">{lens_icons}</div><p class="release-topics">Explore the governance model,<br>system maps and reference records.</p><p class="release-cta">Follow for the website release.</p><p class="release-question">What should your agents understand<br>beyond what they’re allowed to access?</p>''','Website release in preparation',False))

page=(ROOT/'index.html').read_text()
page=re.sub(r'<main>.*?</main>','<main>\n'+'\n\n'.join(slides)+'\n</main>',page,flags=re.S)
(ROOT/'index.html').write_text(page)
print('Built eight diagram-led slides.')
