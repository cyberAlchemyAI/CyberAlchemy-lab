"""Render the local capability-definition, implementation and review carousel."""
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent
TOTAL = 9

def icon(name):
    return f'<img src="assets/{name}.svg" alt="" aria-hidden="true">'

def slide(number, cls, title, body, label, example=True):
    return f'''<div class="frame"{' hidden' if number>1 else ''}><section class="slide {cls}" aria-labelledby="slide-{number}">
<header><img class="logo" src="assets/logo.svg" alt="CyberAlchemy Lab"></header>
<h{'1' if number==1 else '2'} id="slide-{number}">{title}</h{'1' if number==1 else '2'}>
{body}<footer><span>{number:02d} / {TOTAL:02d}</span></footer></section></div>'''

lenses=''.join(f'<span class="{key}">{icon(asset)}<b>{label}</b><small>{meaning}</small></span>' for key,asset,label,meaning in [('authority','book-open','Authority','What sets the rules'),('provenance','route','Provenance','Where claims come from'),('lifecycle','refresh-cw','Lifecycle','Where work stands')])
slides=[]
slides.append(slide(1,'cover capability-cover','Your agent<br>has permission.<br>Who defines “done”?',f'''<img class="cover-orb" src="assets/orb.webp" alt=""><p class="cover-lead">Permission doesn’t settle<br>what counts as complete.</p><div class="cover-lenses">{lenses}</div>''','Governance for agent work',False))

slides.append(slide(2,'capability-overview story-overview','What should this<br>feature do?',f'''<p class="product-anchor">A customer needs its active records exported.</p>
<div class="overview-flow diagram" role="img" aria-label="The customer needs an export of active records. First define what complete means. One AI agent then writes proposed code; another checks the code and output against that definition. Later slides give each agent separate permissions. A unique record ID identifies one source record.">
<div class="outcome-node authority">{icon('book-open')}<strong>Define what “complete” means</strong></div>
<div class="story-stem" aria-hidden="true">↓</div>
<div class="overview-pair"><div>{icon('bot')}<strong>Write code</strong></div><div>{icon('bot')}<strong>Review output</strong></div></div>
<div class="overview-link"><span>Code and saved output</span><b aria-hidden="true">→</b><span>Checked against the definition</span></div></div>
<p class="takeaway">A record ID uniquely identifies one record.</p>''','Overview'))

slides.append(slide(3,'definition-page visual-definition','Here’s what<br>“complete” means.',f'''<p class="selection-intro">Select Customer 1’s active records<br>from data saved at one moment.</p>
<div class="selection-visual diagram" role="img" aria-label="A few records illustrate the selection rule applied to the full saved source data. Record 1 belongs to Customer 1 and is active, so its ID is required. Record 10001 belongs to Customer 1 but is inactive, so it is excluded. Record 10021 is active but belongs to another account, so it is excluded. Every ID matching the account and every chosen filter, across the full saved source, must appear in the saved export. This checks identifier coverage only. Values, duplicates and extra identifiers need separate checks. The definition is a draft awaiting owner acceptance.">
<p class="source-excerpt">A few source records</p>
<table class="selection-records"><thead><tr><th>Record ID</th><th>Customer</th><th>Status</th><th></th></tr></thead><tbody>
<tr class="selected-record"><td>1</td><td>Customer 1</td><td>Active</td><td><span class="selection-mark">✓</span> Required</td></tr>
<tr><td>10001</td><td>Customer 1</td><td>Inactive</td><td><span class="selection-mark" aria-label="Excluded">×</span></td></tr>
<tr><td>10021</td><td>Customer 2</td><td>Active</td><td><span class="selection-mark" aria-label="Excluded">×</span></td></tr>
</tbody></table>
<div class="selection-transfer" aria-hidden="true">↓</div>
<div class="export-rule authority">{icon('book-open')}<strong>Every matching ID belongs<br>in the export file.</strong></div>
</div>
<p class="selection-exclusions">Check values, duplicates and extra IDs separately.</p>
<p class="takeaway">The owner must accept this rule.</p>''','Definition content first'))

slides.append(slide(4,'meaning-page story-authority','The owner accepts<br>this definition.',f'''<div class="meaning-flow diagram" role="img" aria-label="The person authorized to set the service’s requirements accepts this exact definition within its scope. It states that every required record ID must be present in the export. This one meaning guides both the agent writing code and the agent reviewing the output. Accepting the definition proves no code conformance and grants no action permissions.">
<div class="authority-owner">{icon('users')}<strong>Person setting<br>the service’s requirements</strong></div>
<div class="connector authority"><span>accepts this definition</span><b aria-hidden="true">↓</b></div>
<div class="shared-criterion authority">{icon('book-open')}<strong>Every required ID<br>must be present.</strong></div>
<svg class="meaning-branches" viewBox="0 0 920 100" preserveAspectRatio="none" aria-hidden="true"><path d="M460 0V40M210 95V40H710V95"/><path d="m199 81 11 14 11-14m478 0 11 14 11-14"/></svg>
<div class="meaning-agents"><div>{icon('bot')}<strong>Write code</strong></div><div>{icon('bot')}<strong>Review output</strong></div></div></div>
<p class="takeaway">The code still has to meet this accepted rule.</p>''','Authority over meaning'))

slides.append(slide(5,'permissions-page visual-permissions','What may<br>each agent do?',f'''<div class="permissions-visual diagram" role="img" aria-label="The accepted definition remains the shared rule: every required record identifier must be present. Neither agent has permission to change that meaning. Separate permissions allow the agent writing code to edit the proposed code and run it on the agreed data. The agent reviewing it may read selected code, source data and the export, compare record identifiers and record a review. A job assignment grants no permission by itself. Neither agent has permission to accept the implementation or put it into use.">
<div class="meaning-anchor authority">{icon('book-open')}<div><strong>Every required ID must be present.</strong><p>Neither may change this accepted meaning.</p></div></div>
<div class="action-lanes">
<div class="action-lane"><div class="action-actor">{icon('bot')}<strong>Agent writing code</strong></div>
<div class="allowed-action">{icon('briefcase-business')}<span>Edit proposed code</span></div>
<div class="allowed-action">{icon('refresh-cw')}<span>Run on agreed data</span></div></div>
<div class="action-lane"><div class="action-actor">{icon('bot')}<strong>Agent reviewing it</strong></div>
<div class="allowed-action">{icon('database')}<span>Read selected source,<br>code and export</span></div>
<div class="allowed-action">{icon('route')}<span>Compare IDs<br>and record the review</span></div></div>
</div>
<div class="use-boundary"><span class="no-use-mark" aria-hidden="true">×</span><strong>Neither may put the code into use.</strong></div>
</div>
<p class="takeaway">Each agent needs separate permission.</p>''','Two jobs, two permission scopes'))

slides.append(slide(6,'conformance-page story-provenance','What did the<br>reviewer check?',f'''<p class="fixture-line">Customer 1’s active records, saved at one moment.</p>
<div class="trace-story diagram" role="img" aria-label="The proposed code uses a fixed source snapshot to produce a saved export. The reviewer uses the exact accepted definition to derive every required ID from Customer 1’s active records in that snapshot, then compares each required ID with the saved output. Ten thousand IDs are required and 9800 of those exact IDs appear in the export. Two hundred required IDs are absent. Keep the exact definition, source, code and output with the review. This is a fictional illustration, not an actual agent run.">
<div class="trace-inputs"><div>{icon('database')}<strong>Saved source</strong></div><span class="trace-arrow" aria-hidden="true">→</span><div>{icon('briefcase-business')}<strong>Code used</strong></div><span class="trace-arrow" aria-hidden="true">→</span><div>{icon('database')}<strong>Saved export</strong></div></div>
<div class="trace-review"><div>{icon('bot')}<strong>Compare each required ID</strong></div><p class="authority">{icon('book-open')}Using the accepted definition</p></div>
<div class="coverage-values"><div><strong>10,000</strong><span>required IDs from source</span></div><div><strong>9,800</strong><span>of those IDs present</span></div></div>
<div class="coverage-track" aria-hidden="true"><span></span><span></span></div>
<div class="trace-gap"><strong>200 missing IDs</strong><span>This export is incomplete.</span></div></div>
<p class="takeaway">Save these exact records with the review.</p>''','Provenance'))

slides.append(slide(7,'delivery-lifecycle story-lifecycle','What happens<br>after the review?',f'''<div class="definition-status authority">{icon('book-open')}<span>The definition is already accepted.</span></div>
<div class="code-timeline diagram" role="img" aria-label="The definition is already accepted and keeps its own lifecycle. The code is still a candidate with a review reporting 200 missing required IDs. A possible future route is to revise the code, gather new results, review again and seek an owner decision for that exact revised version. Only if accepted would the code become accepted. Putting that accepted version into use needs separate permission. The dashed future route does not assert that acceptance or activation has occurred.">
<div class="code-state current-code"><span class="state-point">{icon('briefcase-business')}</span><div><strong>Candidate code</strong><p>200 required IDs missing</p></div></div>
<div class="state-change"><span class="state-line" aria-hidden="true"></span><p>Revise and review again.<br>If the owner accepts this version…</p></div>
<div class="code-state future-code"><span class="state-point">{icon('users')}</span><strong>Accepted code</strong></div>
<div class="state-change"><span class="state-line" aria-hidden="true"></span><p>Obtain separate permission to use it</p></div>
<div class="code-state future-code"><span class="state-point">{icon('refresh-cw')}</span><strong>In use</strong></div></div>
<p class="takeaway">Later steps depend on separate decisions.</p>''','Lifecycle'))

slides.append(slide(8,'delivery-memory story-memory','How does the next<br>agent pick this up?',f'''<div class="memory-story diagram" role="img" aria-label="Each machine agent exists for one temporary session. Work and review sessions end with their private short-term memory. Their work is recorded under project rules and becomes part of shared Project State. It includes the exact definition and decisions, code version, source and output, and review. A later session receives selected task context and a view of how the records connect. Permissions are separately required; prior agent memory and permissions are not inherited.">
<div class="session-endpoints"><div>{icon('bot')}<strong>Work session</strong></div><div>{icon('bot')}<strong>Review session</strong></div></div>
<div class="connector"><span>record under project rules</span><b aria-hidden="true">↓</b></div>
<div class="memory-records"><strong>Saved project records</strong><div class="record-grid"><div class="authority">{icon('book-open')}<span>Definition and decisions</span></div><div>{icon('briefcase-business')}<span>Code version</span></div><div class="provenance">{icon('database')}<span>Source and output</span></div><div>{icon('route')}<span>Review</span></div></div></div>
<div class="connector"><span>select records and their connections</span><b aria-hidden="true">↓</b></div>
<div class="new-session">{icon('bot')}<strong>New session</strong></div></div>
<p class="takeaway">Short-term memory ends with the session.<br>Permissions are granted separately.</p>''','Project continuity'))

slides.append(slide(9,'release story-release','Inside an open<br>company brain.',f'''<img class="release-orb" src="assets/orb.webp" alt="">
<div class="governance-ring diagram" role="img" aria-label="Authority sets the meaning and permitted actions. Provenance traces the origins and evidence of records. Lifecycle states where the work stands and governs transitions. These three lenses connect around shared knowledge and project records.">
<svg viewBox="0 0 920 530" aria-hidden="true"><path d="M170 165L350 215M750 165L570 215M460 355V365"/></svg>
<div class="ring-lens authority">{icon('book-open')}<strong>Authority</strong><span>What sets the rules</span></div>
<div class="ring-lens provenance">{icon('route')}<strong>Provenance</strong><span>Where claims come from</span></div>
<div class="ring-center">{icon('database')}<strong>Shared knowledge</strong></div>
<div class="ring-lens lifecycle">{icon('refresh-cw')}<strong>Lifecycle</strong><span>Where work stands</span></div></div>
<p class="release-cta">Follow for the website release.</p>
<p class="release-question">When your agent says “ready”,<br>whose definition is it using?</p>''','Website release in preparation',False))

page=(ROOT/'index.html').read_text()
page=re.sub(r'<main>.*?</main>','<main>\n'+'\n\n'.join(slides)+'\n</main>',page,flags=re.S)
page=page.replace('Math.min(7,index)','Math.min(frames.length-1,index)').replace("next.disabled=current===7","next.disabled=current===frames.length-1").replace("+' / 8'","+' / '+frames.length").replace('>1 / 8<','>1 / 9<')
(ROOT/'index.html').write_text(page)
print('Rendered nine slides: overview, definition, acceptance, agent work, evidence, lifecycle and continuity.')
