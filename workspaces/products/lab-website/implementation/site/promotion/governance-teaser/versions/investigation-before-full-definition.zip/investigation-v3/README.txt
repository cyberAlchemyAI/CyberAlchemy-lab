Website-style investigation carousel

Eight slides following the proposed customer incident story. The original and alternative-v2 editions are preserved.

Run python3 build.py to generate index.html and ../compare-v3.html. The source copies the preview website’s KEP design tokens, logo, orb and central company-brain artwork. The cover follows the centered sans-serif homepage; inner pages use the website’s serif section headings, warm paper, thin rules and UI text. Lucide icons retain their license.

post.txt is the caption. document-title.txt is the LinkedIn document title. The exported PDF is cyberalchemy-governance-investigation.pdf. PNGs and preview.png show the eight slides. export.json records hashes and page counts. production.json preserves source identities and model boundaries.

The omission is confirmed by exact ID membership, not counts alone. Its cause and a recovery are not established. Definition v1 is accepted while Export code v1 remains pending. Proposed new code needs fresh review and exact-version acceptance; customer release requires separate permission. Machine agents remain temporary, with private session memory and project-based continuity through selected views and current permissions.

All content is a local fictional draft. No publication, real grants, actual executions or canonical admissions occur.
