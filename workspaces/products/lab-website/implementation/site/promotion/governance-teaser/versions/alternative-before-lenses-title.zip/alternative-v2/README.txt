CyberAlchemy Lab governance teaser, separate alternative

This eight-slide version uses the same exact fictional Customer 1 export example as the current nine-slide version. It does not replace the current version.

index.html: slideshow
post.txt: new LinkedIn caption
build.py: editable content and comparison-page generator
slides.css: new presentation design
compare.css: comparison page design
production.json: semantic scope and hashes of preserved original files
export.json: exported PDF and slide metadata

Run python3 build.py to rebuild the slideshow and ../compare-v2.html. Render in Chromium at 1080 × 1350 with background graphics for the PDF and PNGs. Assets are copied from the current edition, including the KEP brand images and licensed Lucide icons.

The comparison page aligns story sections. The new request/definition slide corresponds to two current slides. Both captions are available side by side.

Definition before acceptance. Separate permissions. Explicit Customer 1 AND Active filter. Same saved database copy. Exact selected IDs compared with the file. Saved failed review before future release. Temporary agent sessions and separately granted permissions. No bottom commentary or slide release invitation.

Local drafts only. No publishing or real decisions, runs or test results are asserted.
