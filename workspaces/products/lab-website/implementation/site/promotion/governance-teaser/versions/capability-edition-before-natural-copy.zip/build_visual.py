"""Render the local capability-definition, implementation and review carousel."""
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent
TOTAL = 9

def icon(name):
    return f'<img src="assets/{name}.svg" alt="" aria-hidden="true">'

def slide(number, cls, title, body, label, example=True):
    footer='Customer export · illustrative example' if example else 'CyberAlchemy Lab · website preview'
    return f'''<div class="frame"{' hidden' if number>1 else ''}><section class="slide {cls}" aria-labelledby="slide-{number}">
<header><img class="logo" src="assets/logo.svg" alt="CyberAlchemy Lab"><span>{label}</span></header>
<h{'1' if number==1 else '2'} id="slide-{number}">{title}</h{'1' if number==1 else '2'}>
{body}<footer><span>{footer}</span><span>{number:02d} / {TOTAL:02d}</span></footer></section></div>'''

lenses=''.join(f'<span class="{key}">{icon(asset)}<b>{label}</b></span>' for key,asset,label in [('authority','book-open','Authority'),('provenance','route','Provenance'),('lifecycle','refresh-cw','Lifecycle')])
slides=[]
slides.append(slide(1,'cover capability-cover','Permission to act<br>isn’t authority<br>to define “done”.',f'''<img class="cover-orb" src="assets/orb.webp" alt=""><p class="cover-lead">The agents implement and review.<br>The definition sets the criterion.</p><div class="cover-lenses">{lenses}</div>''','Governance for agent work',False))

slides.append(slide(2,'capability-overview','Start with the outcome.<br>Then choose the code.',f'''<p class="product-anchor">Customer-data service → operations analysts</p>
<div class="overview-flow diagram" role="img" aria-label="The product capability states the required outcome: an ID-complete customer export. A technical implementation is a candidate realization. A review assesses evidence against the definition. Producing code is not itself conformance or admission.">
<div class="outcome-node">{icon('book-open')}<div><span>Product capability</span><strong>ID-complete customer export</strong></div></div>
<div class="connector"><span>defines the required outcome</span><b>↓</b></div>
<div class="overview-pair"><div>{icon('briefcase-business')}<strong>Implementation</strong><span>A candidate realization</span></div><div>{icon('route')}<strong>Review</strong><span>An evidence-based assessment</span></div></div>
<div class="overview-link"><span>candidate + output</span><b>→</b><span>assess against definition</span></div></div>
<p class="takeaway">Defining the outcome does not implement it.</p>''','Overview'))

slides.append(slide(3,'definition-page','Show the definition<br>before the approval.',f'''<div class="definition-sheet diagram">
<div class="sheet-head"><strong>ID-complete customer export</strong><span>v1 · draft</span></div>
<dl><div><dt>Product / users</dt><dd>Customer-data service / operations analysts</dd></div>
<div><dt>Meaning</dt><dd>Produce an export containing every required record ID.</dd></div>
<div><dt>Input scope</dt><dd>Fixed snapshot S, account A, filters F.</dd></div>
<div><dt>Output</dt><dd>Saved export E.</dd></div>
<div><dt>Success criterion</dt><dd>No required IDs are missing from E.</dd></div>
<div><dt>Boundaries</dt><dd>ID coverage only. Value accuracy and duplicates need separate criteria.</dd></div></dl></div>
<p class="takeaway">Authored content. Acceptance comes next.</p>''','Definition content first'))

slides.append(slide(4,'meaning-page','Who gives this<br>meaning authority?',f'''<div class="meaning-flow diagram" role="img" aria-label="After its meaning and boundaries are specified, the service owner accepts exact definition v1 within its scope. That accepted meaning becomes the shared criterion for implementation work and review. This decision grants neither agent action permission and proves no code conformance.">
<div class="accept-node">{icon('users')}<div><strong>Service owner accepts v1</strong><span>Exact definition · declared scope</span></div></div>
<div class="connector authority"><span>establishes the governing criterion</span><b>↓</b></div>
<div class="shared-criterion authority">{icon('book-open')}<strong>“Complete” requires<br>zero missing required IDs.</strong></div>
<svg class="meaning-branches" viewBox="0 0 920 100" preserveAspectRatio="none" aria-hidden="true"><path d="M460 0V40M210 95V40H710V95"/><path d="m199 81 11 14 11-14m478 0 11 14 11-14"/></svg>
<div class="meaning-agents"><div>{icon('bot')}<strong>Implementation agent</strong><span>Works toward the criterion</span></div><div>{icon('bot')}<strong>Review agent</strong><span>Assesses against that criterion</span></div></div></div>
<p class="takeaway">Acceptance governs meaning. It does not prove conformance.</p>''','Authority over meaning'))

slides.append(slide(5,'permissions-page','These permissions<br>cannot redefine v1.',f'''<div class="permission-agents diagram" role="img" aria-label="The implementation assignment and the review assignment have different jobs. Separate scoped permissions allow the first agent to edit candidate files and run the fixture, and the second to inspect selected artifacts and prepare a review. Assignments themselves grant no authority. Neither permission authorizes redefining the criterion, admitting code or deploying.">
<div class="permission-lane implementation-lane"><div class="lane-heading">{icon('bot')}<strong>Implementation agent</strong></div><div class="lane-body"><span class="lane-label">Job</span><p>Produce candidate implementation I1.</p><span class="lane-label">Separate permission</span><p>Edit candidate files.<br>Execute the fixed fixture.</p></div></div>
<div class="permission-lane review-lane"><div class="lane-heading">{icon('bot')}<strong>Review agent</strong></div><div class="lane-body"><span class="lane-label">Job</span><p>Assess I1 against definition v1.</p><span class="lane-label">Separate permission</span><p>Inspect selected artifacts.<br>Prepare review material.</p></div></div></div>
<div class="permission-boundary"><b>Neither may redefine the criterion or deploy.</b><span>Assignment names the job. Current permission governs actions.</span></div>''','Two jobs, two permission scopes'))

slides.append(slide(6,'conformance-page','“It runs” does not<br>mean it conforms.',f'''<p class="fixture-line">Fixed S1 · Northstar · status = active</p>
<div class="review-trail diagram" role="img" aria-label="Candidate implementation I1 with build B1 produces saved output E1 for fixed fixture S1, Northstar and status active. The review agent compares exact required IDs with E1 against definition v1. Ten thousand IDs are required and 9800 are present, leaving 200 missing required IDs. The candidate fails the coverage criterion for this fixture. The illustration is not an actual agent run or conformance proof for all inputs.">
<div class="review-source-pair"><div>{icon('briefcase-business')}<strong>I1 · build B1</strong><span>Saved output E1</span></div><div class="authority">{icon('book-open')}<strong>Definition v1</strong><span>Missing IDs must be 0</span></div></div>
<svg class="join" viewBox="0 0 920 105" preserveAspectRatio="none" aria-hidden="true"><path d="M210 0V43H710V0M460 43V99"/><path d="m448 87 12 12 12-12"/></svg>
<div class="review-action">{icon('bot')}<strong>Review agent compares required IDs</strong></div>
<div class="review-counts"><div><b>10,000</b><span>required</span></div><div><b>9,800</b><span>present in E1</span></div></div>
<div class="review-result"><b>200 missing IDs</b><strong>Fails the accepted coverage criterion.</strong></div></div>
<p class="takeaway">Keep exact inputs, code and output with the review.</p>''','Provenance and conformance evidence'))

slides.append(slide(7,'delivery-lifecycle','A review result<br>is not a deployment.',f'''<div class="current-posture"><span>Definition v1: accepted</span><span>I1: candidate · review reports a gap</span></div>
<div class="future-delivery diagram" role="img" aria-label="The accepted definition remains the criterion. Implementation I1 is a candidate with a review reporting 200 missing IDs. Future work must revise and produce fresh exact-target evidence, prepare a review, obtain a separate owner decision for an exact implementation, and obtain separate authority for activation. The diagram is conditional and does not assert that those later steps occurred.">
<div class="future-node"><span>CONDITIONAL NEXT STEPS</span><strong>Revise code + gather fresh evidence</strong></div>
<div class="connector lifecycle"><span>review the new exact version</span><b>↓</b></div>
<div class="future-node"><strong>Owner decides on the implementation</strong></div>
<div class="connector lifecycle"><span>if accepted: separate authority for activation</span><b>↓</b></div>
<div class="future-node"><strong>Implementation put into use</strong></div></div>
<p class="takeaway">Definition acceptance, implementation admission<br>and activation are different events.</p>''','Lifecycle and permitted changes'))

slides.append(slide(8,'delivery-memory','Sessions end.<br>The review trail stays.',f'''<div class="delivery-memory-flow diagram" role="img" aria-label="The implementation and review agents are temporary session-bound actors. Their outputs and review material follow governed recording routes into durable project state. Later sessions receive selected context and ontology views containing the exact definition, implementation, input/output bindings and review material. Their short-term memories start fresh, and permissions remain separately required.">
<div class="memory-source-agents"><div>{icon('bot')}<strong>Implementation session</strong></div><div>{icon('bot')}<strong>Review session</strong></div></div>
<div class="connector"><span>through governed recording</span><b>↓</b></div>
<div class="delivery-project-state">{icon('database')}<strong>Durable project state</strong><div><span>Definition v1</span><span>I1 / B1 / E1</span><span>Fixture S1 / account / filters</span><span>Review R1: 200 missing</span></div></div>
<div class="connector"><span>prepare context + ontology views</span><b>↓</b></div>
<div class="later-session">{icon('bot')}<strong>A later session continues the work</strong></div></div>
<p class="takeaway">Working memory is private to the session.<br>Project state supplies long-term continuity.</p>''','Ephemeral agents, durable knowledge'))

slides.append(slide(9,'release','Inside an open<br>company brain.',f'''<img class="release-orb" src="assets/orb.webp" alt=""><p class="release-intro">CyberAlchemy Lab</p><div class="release-lenses">{lenses}</div><p class="release-topics">Definitions govern meaning.<br>Permissions govern actions.<br>Evidence supports the assessment.</p><p class="release-cta">Follow for the website release.</p><p class="release-question">Who defines “correct”, “complete” and “ready”<br>in your agent system?</p>''','Website release in preparation',False))

page=(ROOT/'index.html').read_text()
page=re.sub(r'<main>.*?</main>','<main>\n'+'\n\n'.join(slides)+'\n</main>',page,flags=re.S)
page=page.replace('Math.min(7,index)','Math.min(frames.length-1,index)').replace("next.disabled=current===7","next.disabled=current===frames.length-1").replace("+' / 8'","+' / '+frames.length").replace('>1 / 8<','>1 / 9<')
(ROOT/'index.html').write_text(page)
print('Rendered nine slides: overview, definition, acceptance, agent work, evidence, lifecycle and continuity.')
