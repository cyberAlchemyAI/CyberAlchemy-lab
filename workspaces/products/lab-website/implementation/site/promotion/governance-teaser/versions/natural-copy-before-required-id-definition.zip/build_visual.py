"""Render the local capability-definition, implementation and review carousel."""
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent
TOTAL = 9

def icon(name):
    return f'<img src="assets/{name}.svg" alt="" aria-hidden="true">'

def slide(number, cls, title, body, label, example=True):
    footer='Customer export · illustrative example' if example else 'CyberAlchemy Lab · website preview'
    return f'''<div class="frame"{' hidden' if number>1 else ''}><section class="slide {cls}" aria-labelledby="slide-{number}">
<header><img class="logo" src="assets/logo.svg" alt="CyberAlchemy Lab"><span>{label}</span></header>
<h{'1' if number==1 else '2'} id="slide-{number}">{title}</h{'1' if number==1 else '2'}>
{body}<footer><span>{footer}</span><span>{number:02d} / {TOTAL:02d}</span></footer></section></div>'''

lenses=''.join(f'<span class="{key}">{icon(asset)}<b>{label}</b></span>' for key,asset,label in [('authority','book-open','Authority'),('provenance','route','Provenance'),('lifecycle','refresh-cw','Lifecycle')])
slides=[]
slides.append(slide(1,'cover capability-cover','Your agent<br>has permission.<br>Who defines “done”?',f'''<img class="cover-orb" src="assets/orb.webp" alt=""><p class="cover-lead">Before an agent calls its work complete,<br>someone has to define what complete means.</p><div class="cover-lenses">{lenses}</div>''','Governance for agent work',False))

slides.append(slide(2,'capability-overview','What should this<br>feature do?',f'''<p class="product-anchor">Operations analysts need a customer export.</p>
<div class="overview-flow diagram" role="img" aria-label="Operations analysts need an export with every required record identifier. The product capability states this outcome. One agent proposes the code and another reviews its saved output against the definition.">
<div class="outcome-node">{icon('book-open')}<div><span>Product capability</span><strong>Complete customer export</strong></div></div>
<div class="connector"><span>sets out what the export must deliver</span><b>↓</b></div>
<div class="overview-pair"><div>{icon('briefcase-business')}<strong>Implementation</strong><span>Proposed export code</span></div><div>{icon('route')}<strong>Review</strong><span>A check of what the code produced</span></div></div>
<div class="overview-link"><span>Code and saved output</span><b>→</b><span>Checked against the definition</span></div></div>
<p class="takeaway">The definition gives both agents a starting point.</p>''','Overview'))

slides.append(slide(3,'definition-page','Here’s what<br>“complete” means.',f'''<div class="definition-sheet diagram">
<div class="sheet-head"><strong>Complete customer export</strong><span>Draft definition</span></div>
<dl><div><dt>Product and users</dt><dd>Customer-data service for operations analysts</dd></div>
<div><dt>Meaning</dt><dd>Produce an export containing every required record ID.</dd></div>
<div><dt>Input scope</dt><dd>A fixed copy of the data, a chosen account and filters.</dd></div>
<div><dt>Output</dt><dd>A saved export file.</dd></div>
<div><dt>Success criterion</dt><dd>Every required record ID appears in the file.</dd></div>
<div><dt>Boundaries</dt><dd>Record IDs only. Values and duplicate rows need separate checks.</dd></div></dl></div>
<p class="takeaway">The owner still needs to accept this draft.</p>''','Definition content first'))

slides.append(slide(4,'meaning-page','The owner accepts<br>this definition.',f'''<div class="meaning-flow diagram" role="img" aria-label="Once the outcome and its boundaries are written down, the service owner accepts this version of the definition for this product. Both agents use it to guide their work. Acceptance does not prove the code meets the definition or give either agent permission to act.">
<div class="accept-node">{icon('users')}<div><strong>The service owner accepts this version</strong><span>For this product, within the stated scope</span></div></div>
<div class="connector authority"><span>both agents now use this meaning</span><b>↓</b></div>
<div class="shared-criterion authority">{icon('book-open')}<strong>“Complete” means every<br>required record ID is present.</strong></div>
<svg class="meaning-branches" viewBox="0 0 920 100" preserveAspectRatio="none" aria-hidden="true"><path d="M460 0V40M210 95V40H710V95"/><path d="m199 81 11 14 11-14m478 0 11 14 11-14"/></svg>
<div class="meaning-agents"><div>{icon('bot')}<strong>Implementation agent</strong><span>Builds the export to meet the definition</span></div><div>{icon('bot')}<strong>Review agent</strong><span>Checks the output against the definition</span></div></div></div>
<p class="takeaway">The code still has to meet the accepted definition.</p>''','Authority over meaning'))

slides.append(slide(5,'permissions-page','What is each<br>agent allowed to do?',f'''<div class="permission-agents diagram" role="img" aria-label="One agent writes the proposed export code. A separate permission allows edits and a run on the agreed sample. Another agent reviews the code and output, with permission to inspect the selected material and write up the review. Being assigned a job grants no permission by itself. Neither agent has permission to change the definition, accept the code or deploy it.">
<div class="permission-lane implementation-lane"><div class="lane-heading">{icon('bot')}<strong>Implementation agent</strong></div><div class="lane-body"><span class="lane-label">Job</span><p>Write the proposed export code.</p><span class="lane-label">Allowed actions</span><p>Edit the proposed code.<br>Run it on the agreed sample.</p></div></div>
<div class="permission-lane review-lane"><div class="lane-heading">{icon('bot')}<strong>Review agent</strong></div><div class="lane-body"><span class="lane-label">Job</span><p>Check the code and output against the definition.</p><span class="lane-label">Allowed actions</span><p>Inspect the selected code and output.<br>Write up the review.</p></div></div></div>
<div class="permission-boundary"><b>Neither agent has permission to change the definition or deploy.</b><span>Each agent needs permission for the actions its job requires.</span></div>''','Two jobs, two permission scopes'))

slides.append(slide(6,'conformance-page','The export ran.<br>200 IDs are missing.',f'''<p class="fixture-line">Northstar’s active records, from the agreed fixed copy.</p>
<div class="review-trail diagram" role="img" aria-label="The proposed code produces a saved export for a fixed copy of Northstar’s active records. The review compares the required record identifiers with the identifiers in the export, using the accepted definition. Ten thousand are required and 9800 appear in the output. Two hundred are missing. The export is incomplete for this sample. This fictional example does not describe an actual agent run.">
<div class="review-source-pair"><div>{icon('briefcase-business')}<strong>The proposed code</strong><span>The saved export</span></div><div class="authority">{icon('book-open')}<strong>The accepted definition</strong><span>Every required ID belongs in the file</span></div></div>
<svg class="join" viewBox="0 0 920 105" preserveAspectRatio="none" aria-hidden="true"><path d="M210 0V43H710V0M460 43V99"/><path d="m448 87 12 12 12-12"/></svg>
<div class="review-action">{icon('bot')}<strong>The review agent looks for missing IDs</strong></div>
<div class="review-counts"><div><b>10,000</b><span>required record IDs</span></div><div><b>9,800</b><span>IDs in the saved export</span></div></div>
<div class="review-result"><b>200 missing IDs</b><strong>For this sample, the export is incomplete.</strong></div></div>
<p class="takeaway">Save the input, code and output versions with the review.</p>''','Provenance: what the review used'))

slides.append(slide(7,'delivery-lifecycle','What happens<br>after the review?',f'''<div class="current-posture"><span>The definition is accepted.</span><span>The proposed code still needs work.</span></div>
<div class="future-delivery diagram" role="img" aria-label="The definition has been accepted but the proposed code still needs work. A possible next step is to revise the code, collect fresh evidence and review the revised version. The owner would then decide whether to accept that version of the implementation. Putting it into use requires separate permission. These are possible future steps.">
<div class="future-node"><span>A possible path from here</span><strong>Revise the code and collect fresh evidence</strong></div>
<div class="connector lifecycle"><span>review the revised version</span><b>↓</b></div>
<div class="future-node"><strong>The owner decides whether to accept this version</strong></div>
<div class="connector lifecycle"><span>if accepted, obtain permission to put it into use</span><b>↓</b></div>
<div class="future-node"><strong>Put the accepted implementation into use</strong></div></div>
<p class="takeaway">Accepting a definition, accepting code and putting it<br>into use each require their own decision.</p>''','Lifecycle: where the work stands'))

slides.append(slide(8,'delivery-memory','How does the next<br>agent pick this up?',f'''<div class="delivery-memory-flow diagram" role="img" aria-label="The agents work in temporary sessions. The Lab’s recording process saves their work and review material in project state. Later sessions receive selected context and a view of how the records connect, including the definition, code, inputs, outputs and review. Short-term memory ends with the session. Permissions remain separately required.">
<div class="memory-source-agents"><div>{icon('bot')}<strong>The agent writing the code</strong></div><div>{icon('bot')}<strong>The agent reviewing it</strong></div></div>
<div class="connector"><span>save records through the Lab’s recording process</span><b>↓</b></div>
<div class="delivery-project-state">{icon('database')}<strong>Saved project state</strong><div><span>The accepted definition</span><span>The code, build and export</span><span>The input, account and filters</span><span>The review: 200 missing IDs</span></div></div>
<div class="connector"><span>prepare context and a view of how the records connect</span><b>↓</b></div>
<div class="later-session">{icon('bot')}<strong>A later agent gets context for its work</strong></div></div>
<p class="takeaway">The agent’s short-term memory ends with its session.<br>Later work draws on the saved project state.</p>''','What carries forward'))

slides.append(slide(9,'release','Inside an open<br>company brain.',f'''<img class="release-orb" src="assets/orb.webp" alt=""><p class="release-intro">CyberAlchemy Lab</p><div class="release-lenses">{lenses}</div><p class="release-topics">See how a team defines its work,<br>checks what its agents produce<br>and decides what happens next.</p><p class="release-cta">Follow for the website release.</p><p class="release-question">When your agent says “ready”,<br>whose definition is it using?</p>''','Website release in preparation',False))

page=(ROOT/'index.html').read_text()
page=re.sub(r'<main>.*?</main>','<main>\n'+'\n\n'.join(slides)+'\n</main>',page,flags=re.S)
page=page.replace('Math.min(7,index)','Math.min(frames.length-1,index)').replace("next.disabled=current===7","next.disabled=current===frames.length-1").replace("+' / 8'","+' / '+frames.length").replace('>1 / 8<','>1 / 9<')
(ROOT/'index.html').write_text(page)
print('Rendered nine slides: overview, definition, acceptance, agent work, evidence, lifecycle and continuity.')
