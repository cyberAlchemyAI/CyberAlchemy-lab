CyberAlchemy Lab: permission, meaning and agent work

Nine-slide LinkedIn teaser, with an overview followed by a reader-facing definition with an explicit record-selection rule, owner acceptance, separate implementation and review agents, evidence, lifecycle and project continuity.

Upload cyberalchemy-governance-teaser.pdf as a LinkedIn document. Use document-title.txt as its title and post.txt as its caption.

index.html and slides.css are editable source. build_visual.py regenerates the nine slides. After changing text in that script, run python3 build_visual.py in this folder. The browser controls derive their page count from the frames.

To re-export after editing, open index.html in Chrome or Edge. Print to PDF with background graphics enabled. The print stylesheet defines nine equal portrait pages.

capability-example.json preserves the entire illustrative semantic example, assignments, permission boundaries, exact fixture and review bindings. production.json records the model sources and presentation scope.

slide-1.png through slide-9.png are full-resolution previews. preview.png shows the complete sequence.

The assets folder contains the brand assets and Lucide icons with their license. No release date or public website address is invented. Nothing has been published.

The slides introduce the example with “Suppose”. Header section tags, draft badges, task labels and footer captions are removed. Definition fields, lens names and page numbers remain. Exact scope and fictional standing remain recorded in capability-example.json and production.json.

The definition slide now visualizes account/filter selection using a few source records. The permissions slide separates the owner’s accepted meaning from each agent’s allowed actions with icon rows. The caption and exact underlying example are unchanged.

The complete carousel now follows a visual sequence for authority, action permissions, provenance, lifecycle and project continuity. Generic Customer 1 and Customer 2 appear in the source selection, caption and exact fictional example. governance-slides.png previews the three governance slides together.

editorial-review.txt explains the critique and rewrite. The editorial edition removes repeated framing and varies slide headings while preserving the exact fictional model and visual sequence.
