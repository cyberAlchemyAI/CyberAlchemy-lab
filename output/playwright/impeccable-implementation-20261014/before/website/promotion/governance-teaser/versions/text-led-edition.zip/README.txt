CyberAlchemy Lab: governance for agent work

Upload cyberalchemy-governance-teaser.pdf as a LinkedIn document. Use document-title.txt as its title and post.txt as the post caption.

index.html and slides.css are the editable slideshow source. The assets folder contains the logo, orb and Lucide SVGs with their license. Open index.html to review the slideshow.

To re-export after editing, open index.html in Chrome or Edge. Print to PDF with background graphics enabled. The print stylesheet defines eight equal portrait pages.

slide-1.png through slide-8.png are full-resolution previews. preview.png shows the whole sequence.

production.json records the source bindings and editorial decisions. No release date or public website address has been invented.
