"""Render the local capability-definition, implementation and review carousel."""
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent
TOTAL = 9

def icon(name):
    return f'<img src="assets/{name}.svg" alt="" aria-hidden="true">'

def slide(number, cls, title, body, label, example=True):
    return f'''<div class="frame"{' hidden' if number>1 else ''}><section class="slide {cls}" aria-labelledby="slide-{number}">
<header><img class="logo" src="assets/logo.svg" alt="CyberAlchemy Lab"></header>
<h{'1' if number==1 else '2'} id="slide-{number}">{title}</h{'1' if number==1 else '2'}>
{body}<footer><span>{number:02d} / {TOTAL:02d}</span></footer></section></div>'''

lenses=''.join(f'<span class="{key}">{icon(asset)}<b>{label}</b><small>{meaning}</small></span>' for key,asset,label,meaning in [('authority','book-open','Authority','What sets the rules'),('provenance','route','Provenance','Where claims come from'),('lifecycle','refresh-cw','Lifecycle','Where work stands')])
slides=[]
slides.append(slide(1,'cover capability-cover','Your agent<br>has permission.<br>Who defines “done”?',f'''<img class="cover-orb" src="assets/orb.webp" alt=""><p class="cover-lead">Before an agent calls its work complete,<br>someone has to define what complete means.</p><div class="cover-lenses">{lenses}</div>''','Governance for agent work',False))

slides.append(slide(2,'capability-overview','What should this<br>feature do?',f'''<p class="product-anchor">Suppose Northstar’s team needs an export of its active records.</p>
<div class="overview-flow diagram" role="img" aria-label="Suppose Northstar’s team needs an export of its active records. Each record has a unique identifier. The definition states the outcome before code is chosen. One AI agent writes proposed export code and another reviews the output against that definition.">
<div class="outcome-node">{icon('book-open')}<div><strong>Complete customer export</strong></div></div>
<div class="connector"><span>sets out what the export must deliver</span><b>↓</b></div>
<div class="overview-pair"><div>{icon('briefcase-business')}<strong>Export code</strong><span>One AI agent writes a proposed version</span></div><div>{icon('route')}<strong>Review</strong><span>Another agent checks what it produced</span></div></div>
<div class="overview-link"><span>Code and saved output</span><b>→</b><span>Checked against the definition</span></div></div>
<p class="takeaway">A record ID is a unique code identifying one record.</p>''','Overview'))

slides.append(slide(3,'definition-page','Here’s what<br>“complete” means.',f'''<div class="definition-sheet diagram">
<div class="sheet-head"><strong>Complete customer export</strong></div>
<dl><div><dt>Meaning</dt><dd>An export containing every required record ID.</dd></div>
<div><dt>Input scope</dt><dd>Data saved at one moment, a chosen account and filters.</dd></div>
<div><dt>Required IDs</dt><dd>IDs of all records for that account meeting every filter.</dd></div>
<div><dt>Output</dt><dd>A saved export file.</dd></div>
<div><dt>Success criterion</dt><dd>Every required record ID appears in the file.</dd></div>
<div><dt>Boundaries</dt><dd>Values, duplicates and extra IDs need separate checks.</dd></div></dl></div>
<p class="takeaway">The owner still needs to accept this draft.</p>''','Definition content first'))

slides.append(slide(4,'meaning-page','The owner accepts<br>this definition.',f'''<div class="meaning-flow diagram" role="img" aria-label="The person authorized to set the service’s requirements accepts this exact version of the definition within its stated scope. Both agents use it to judge whether the export includes every required record identifier. Accepting the definition does not prove that the code meets it or grant either agent permission to act.">
<div class="accept-node">{icon('users')}<div><strong>The person who sets its requirements</strong><span>accepts this version as the rule for this export</span></div></div>
<div class="connector authority"><span>both agents use it to judge completeness</span><b>↓</b></div>
<div class="shared-criterion authority">{icon('book-open')}<strong>“Complete” means every<br>required record ID is present.</strong></div>
<svg class="meaning-branches" viewBox="0 0 920 100" preserveAspectRatio="none" aria-hidden="true"><path d="M460 0V40M210 95V40H710V95"/><path d="m199 81 11 14 11-14m478 0 11 14 11-14"/></svg>
<div class="meaning-agents"><div>{icon('bot')}<strong>Agent writing code</strong><span>Builds the export to meet the definition</span></div><div>{icon('bot')}<strong>Agent reviewing it</strong><span>Checks the output against the definition</span></div></div></div>
<p class="takeaway">Accepting the rule doesn’t show whether the code meets it.</p>''','Authority over meaning'))

slides.append(slide(5,'permissions-page','What is each<br>agent allowed to do?',f'''<div class="permission-agents diagram" role="img" aria-label="The agent writing code has permission to edit the proposed code and run it on the agreed data. The agent reviewing it has permission to inspect selected code, source data and the export, compare identifiers and write the review. A job assignment grants no permission by itself. Neither agent has permission to change the accepted definition, accept the implementation or put the code into use.">
<div class="permission-lane implementation-lane"><div class="lane-heading">{icon('bot')}<strong>Agent writing code</strong></div><div class="lane-body"><p>It has permission to edit the proposed code and run it on the agreed data.</p></div></div>
<div class="permission-lane review-lane"><div class="lane-heading">{icon('bot')}<strong>Agent reviewing it</strong></div><div class="lane-body"><p>It has permission to read selected code, source data and the export, compare IDs and write the review.</p></div></div></div>
<div class="permission-boundary"><b>Neither agent may change the accepted definition or put the code into use.</b><span>A job assignment alone doesn’t grant these permissions.</span></div>''','Two jobs, two permission scopes'))

slides.append(slide(6,'conformance-page','The export ran.<br>200 IDs are missing.',f'''<p class="fixture-line">Choose Northstar’s account and records marked active.</p>
<div class="review-trail diagram" role="img" aria-label="The accepted definition selects required identifiers from every record in the fixed source data that belongs to Northstar and has active status. Inactive records and other accounts do not match. The review compares those source identifiers with the saved export produced by the proposed code. There are ten thousand matching source identifiers and 9800 appear in the export. Two hundred required identifiers are absent. This fictional example does not describe an actual agent run.">
<div class="review-source-pair"><div class="provenance">{icon('book-open')}<strong>The saved source data</strong><span>Northstar records with active status</span></div><div>{icon('briefcase-business')}<strong>The saved export</strong><span>From the proposed code</span></div></div>
<svg class="join" viewBox="0 0 920 105" preserveAspectRatio="none" aria-hidden="true"><path d="M210 0V43H710V0M460 43V99"/><path d="m448 87 12 12 12-12"/></svg>
<div class="review-action">{icon('bot')}<strong>Compare source IDs with export IDs</strong></div>
<div class="review-counts"><div><b>10,000</b><span>IDs matching the selection</span></div><div><b>9,800</b><span>of those IDs in the export</span></div></div>
<div class="review-result"><b>200 missing IDs</b><strong>For this sample, the export is incomplete.</strong></div></div>
<p class="takeaway">Select the required IDs from the source before reviewing.</p>''','Provenance: what the review used'))

slides.append(slide(7,'delivery-lifecycle','What happens<br>after the review?',f'''<div class="current-posture"><span>The definition is accepted.</span><span>The proposed code still needs work.</span></div>
<div class="future-delivery diagram" role="img" aria-label="The definition has been accepted but the proposed code still needs work. A possible next step is to revise the code, collect fresh evidence and review that code and its saved output. The owner would then decide whether to accept that version of the implementation. Putting it into use requires separate permission. These are possible future steps.">
<div class="future-node"><strong>The team could revise the code and save new results</strong></div>
<div class="connector lifecycle"><span>review that code and its saved output</span><b>↓</b></div>
<div class="future-node"><strong>The owner decides whether to accept the revised code</strong></div>
<div class="connector lifecycle"><span>if accepted, obtain permission to put it into use</span><b>↓</b></div>
<div class="future-node"><strong>Put the accepted code into use</strong></div></div>
<p class="takeaway">Accepting a definition, accepting code and putting it<br>into use each require their own decision.</p>''','Lifecycle: where the work stands'))

slides.append(slide(8,'delivery-memory','How does the next<br>agent pick this up?',f'''<div class="delivery-memory-flow diagram" role="img" aria-label="Each agent exists for a temporary work session. Its short-term memory belongs to that session and ends with it. Work is recorded under the project’s rules into shared project state. Later agents receive selected records and a view of how they connect, including the accepted definition, code versions, inputs, saved outputs and review. Their permissions are set separately.">
<div class="memory-source-agents"><div>{icon('bot')}<strong>The agent writing the code</strong></div><div>{icon('bot')}<strong>The agent reviewing it</strong></div></div>
<div class="connector"><span>record the work under the project’s rules</span><b>↓</b></div>
<div class="delivery-project-state">{icon('database')}<strong>Saved project records</strong><div><span>The accepted definition</span><span>The code version and export</span><span>The source data and selection</span><span>The review of the missing IDs</span></div></div>
<div class="connector"><span>select relevant records and show their connections</span><b>↓</b></div>
<div class="later-session">{icon('bot')}<strong>A new agent reads these records</strong></div></div>
<p class="takeaway">Each agent exists for a temporary work session.<br>Its short-term memory ends with that session.</p>''','What carries forward'))

slides.append(slide(9,'release','Inside an open<br>company brain.',f'''<img class="release-orb" src="assets/orb.webp" alt=""><div class="release-lenses">{lenses}</div><p class="release-topics">See how a team defines its work,<br>checks what its agents produce<br>and decides what happens next.</p><p class="release-cta">Follow for the website release.</p><p class="release-question">When your agent says “ready”,<br>whose definition is it using?</p>''','Website release in preparation',False))

page=(ROOT/'index.html').read_text()
page=re.sub(r'<main>.*?</main>','<main>\n'+'\n\n'.join(slides)+'\n</main>',page,flags=re.S)
page=page.replace('Math.min(7,index)','Math.min(frames.length-1,index)').replace("next.disabled=current===7","next.disabled=current===frames.length-1").replace("+' / 8'","+' / '+frames.length").replace('>1 / 8<','>1 / 9<')
(ROOT/'index.html').write_text(page)
print('Rendered nine slides: overview, definition, acceptance, agent work, evidence, lifecycle and continuity.')
